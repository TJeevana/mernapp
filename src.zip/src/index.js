/*import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import 'bootstrap/dist/js/bootstrap.bundle.min.js'; 
import 'bootstrap/dist/css/bootstrap.min.css';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
*/

import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';// Import Bootstrap CSS
import 'bootstrap/dist/css/bootstrap.min.css';
import 'font-awesome/css/font-awesome.min.css';

// Import Bootstrap JS (optional, but necessary for some components like modals, tooltips, etc.)
import 'bootstrap/dist/js/bootstrap.bundle.min.js';

//import store from './store'
//import {Provider } from 'react-redux';

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  
     <React.StrictMode>
       <App />
    </React.StrictMode>

);








