import './App.css';
import React from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { HelmetProvider } from 'react-helmet-async';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min.js';

import Home from './components/Home';
import AboutUs from './components/AboutUs';
import Booking from './components/Booking';
import UserNav from './components/UserNav';
import Footer from './components/Footer';
import Login from './components/Login';
import Register from './components/Register';
import Forgotpassword from './components/Forgotpassword';

import Memberdashboard from './components/member/Memberdashboard';
import BookingStatus from './components/member/BookingStatus';
import BookingForm from './components/member/BookingForm';


import AgentDashboard from './components/agent/AgentDashboard';

import AgentStatus from './components/agent/AgentStatus';
import AgentBookingForm from './components/agent/AgentBookingForm';
import AgentPreviousRecords from './components/agent/AgentPreviousRecords';
import AgentCalendar from './components/agent/AgentCalendar';


import BookingDetails from './components/admin/BookingDetails';
import ApprovedBookings from './components/admin/EventDetails';
import Userdetails from './components/admin/UserDetails';
import Admindashboard from './components/admin/Admindashboard';
import AgentBooking from './components/admin/AgentBooking';

import UserContext from './UserContext';
import Calendar from './components/Calendar';
import AgentDashboardContent from './components/agent/AgentDashboardContent';

const App = () => {
  return (
    <Router>
      <HelmetProvider>
        <MainContent />
      </HelmetProvider>
    </Router>
  );
};

const MainContent = () => {
  const location = useLocation();

  // Determine if UserNav and Footer should be hidden
  const isAuthPage = ['/login', '/register', '/forgotpassword'].includes(location.pathname);
  const isDashboardPage = ['/admin/dashboard', '/agent/dashboard', '/member/dashboard'].some(path =>
    location.pathname.startsWith(path)
  );

  return (
    <>
      {/* Conditionally render UserNav */}
      {!isAuthPage && !isDashboardPage && <UserNav />}

      <Routes>
        {/* Public Routes */}
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<AboutUs />} />
        <Route path="/booking" element={<Booking />} />
        <Route path="/bookingForm" element={<BookingForm />} />
        <Route path="/status" element={<BookingStatus />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/forgotpassword" element={<Forgotpassword />} />

        {/* Calendar for all users */}

        <Route path="/calendar" element={<Calendar />} />

        {/* Admin Dashboard */}
        <Route path="/admin/dashboard/*" element={<Admindashboard />}>
          <Route path="booking-details-request" element={<BookingDetails />} />
          <Route path="agent-booking" element={<AgentBooking />} />
          <Route path="user-details" element={<Userdetails />} />
          <Route path='approved-bookings' element={<ApprovedBookings/>}/>
        </Route>


        {/* Agent Dashboard */}
        <Route path="/agent/dashboard/*" element={<AgentDashboard />}>
        <Route path='content' element={<AgentDashboardContent/>}/>
          <Route path="calendar" element={<AgentCalendar />} />
          <Route path="bookingform" element={<AgentBookingForm />} />
          <Route path="previous-records" element={<AgentPreviousRecords />} />
          <Route path="status" element={<AgentStatus />} />
        </Route>


        {/* Member Dashboard */}
        <Route path="/member/dashboard/*" element={<Memberdashboard />} />
      </Routes>

      {/* Conditionally render Footer */}
      {!isAuthPage && !isDashboardPage && <Footer />}
    </>
  );
};

export default App;
