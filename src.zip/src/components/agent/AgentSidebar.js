import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import './AgentSidebar.css';
import { FaUserCircle } from 'react-icons/fa';

const AgentSidebar = () => {
  const [isOpen, setIsOpen] = useState(true);
  const location = useLocation(); // Access location object
  const { email } = location.state || {};  // Extract email from location.state
  
  // Store email in localStorage when it is available
  useEffect(() => {
    if (email) {
      localStorage.setItem('agentEmail', email); // Store email in localStorage
    }
  }, [email]);

  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  // Get email from localStorage if not passed via location.state
  const storedEmail = email || localStorage.getItem('agentEmail');

  return (
    <div className={`agent-sidebar ${isOpen ? 'open' : 'closed'}`}>
      <button className="toggle-btn" onClick={toggleSidebar}>
        {isOpen ? <i className="fa fa-bars"></i> : 'Close'}
      </button>
      <h3>VTCC</h3>
      <FaUserCircle size={80} className="mb-2" />
      <p>{storedEmail ? storedEmail : 'Agent Gmail'}</p> {/* Display email from localStorage */}
      <p>Agent</p>
      <br />
      <ul>
        <li>
          <NavLink
            to="/agent/dashboard/content" state={{email:storedEmail}}
            className={({ isActive }) => isActive ? 'active' : ''} 
            end  // Ensure exact matching
          >
            <i className="fa fa-home-alt"></i> Dashboard
          </NavLink>
        </li>
        <li>
          <NavLink
            to="/agent/dashboard/calendar" state={{ email: storedEmail }}
            className={({ isActive }) => isActive ? 'active' : ''}
          >
            <i className="fa fa-calendar-alt"></i> Calendar
          </NavLink>
        </li>
        <li>
          <NavLink
            to="/agent/dashboard/bookingform" state={{email:storedEmail}}
            className={({ isActive }) => isActive ? 'active' : ''}
          >
            <i className="fa fa-file-alt"></i> Booking Form
          </NavLink>
        </li>
        <li>
          <NavLink
            to="/agent/dashboard/status" state={{email:storedEmail}}
            className={({ isActive }) => isActive ? 'active' : ''}
          >
            <i className="fa fa-check-circle"></i> Booking Status
          </NavLink>
        </li>
        <li>
          <NavLink
            to="/agent/dashboard/previous-records" state={{email:storedEmail}}
            className={({ isActive }) => isActive ? 'active' : ''}
          >
            <i className="fa fa-history"></i> Previous Records
          </NavLink>
        </li>
        <li>
          <NavLink
            to="/login"
            className={({ isActive }) => isActive ? 'active' : ''}
          >
            <i className="fa fa-sign-out-alt"></i> Signout
          </NavLink>
        </li>
      </ul>
    </div>
  );
};

export default AgentSidebar;
