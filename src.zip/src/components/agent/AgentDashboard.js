import React from 'react';
import { useLocation, Route, Routes } from 'react-router-dom';
import AgentSidebar from './AgentSidebar';
import AgentBookingForm from './AgentBookingForm';
import AgentStatus from './AgentStatus';
import AgentPreviousRecords from './AgentPreviousRecords';
import AgentCalendar from './AgentCalendar';
import Login from '../Login';
import AgentDashboardContent from './AgentDashboardContent';
import './AgentDashboard.css'; // Custom styles for the dashboard

const AgentDashboard = () => {
  
  return (
    <div className="agent-dashboard">
      <AgentSidebar /> {/* Sidebar navigation */}
      <div className="agent-dashboard-content">
        <Routes>
          <Route path="Content" element={<AgentDashboardContent />} />
          <Route path="bookingform" element={<AgentBookingForm />} />
          <Route path="calendar" element={<AgentCalendar />} />
          <Route path="status" element={<AgentStatus />} />
          <Route path="previous-records" element={<AgentPreviousRecords />} />
          <Route path='/login' element={<Login />} />
        </Routes>
      </div>
    </div>
  );
};

export default AgentDashboard;
