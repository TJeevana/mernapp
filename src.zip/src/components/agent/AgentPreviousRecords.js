import React from 'react';

const AgentPreviousRecords = () => {
  return (
    <div>
      <h2>Previous Records</h2>
      {/* Display records here */}
      <p>Here are the previous booking records.</p>
    </div>
  );
};

export default AgentPreviousRecords;
