import React, { useState, useEffect} from 'react';
import Calendar from 'react-calendar';
import { useLocation } from 'react-router-dom';

import 'react-calendar/dist/Calendar.css'; // Import calendar styles
import { Button } from '@mui/material';
import axios from 'axios'; // Import axios for API requests
import './AgentCalendar.css'; // Add your custom styles for the calendar component

import { useNavigate } from 'react-router-dom'; // Import useNavigate

const AgentCalendar = () => {
  const [date, setDate] = useState(new Date());
  const [events, setEvents] = useState([]);
  const [approvedBookings, setApprovedBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  const location = useLocation();  // Access location object
  const { email } = location.state || {};
  useEffect(() => {
    if (!email) {
      console.error('No email passed in location.state');
    } else {
      console.log('Email:', email); // Logging email for debugging
    }
  }, [email]); 
  const storedEmail = email || localStorage.getItem('agentEmail');

  const navigate = useNavigate(); // Use navigate for routing

  const onDateChange = (newDate) => {
    setDate(newDate);
    const selectedDateString = newDate.toISOString().split('T')[0];
    const filteredEvents = approvedBookings.filter((booking) => {
      const eventDate = new Date(booking.bookingdetails.date).toISOString().split('T')[0];
      return eventDate === selectedDateString;
    });
    setEvents(filteredEvents);
  };

  useEffect(() => {
    const fetchApprovedBookings = async () => {
      try {
        const response = await axios.get('http://localhost:8000/api/v1/getBooking');
        const bookings = response.data.bookings.filter((booking) => booking.bookingStatus === 'approved');
        setApprovedBookings(bookings);
        setLoading(false);
      } catch (err) {
        console.error('Error fetching bookings:', err);
        setError('Failed to load bookings');
        setLoading(false);
      }
    };
    fetchApprovedBookings();
  }, []);

  return (
    <div className="calendar-layout">
      <div className="calendar-section">
        <h2>Calendar</h2>
        <Calendar
          onChange={onDateChange}
          value={date}
          tileContent={({ date }) => {
            const selectedDateString = date.toISOString().split('T')[0];
            const eventsForThisDay = approvedBookings.filter((booking) => {
              const eventDate = new Date(booking.bookingdetails.date).toISOString().split('T')[0];
              return eventDate === selectedDateString;
            });
            return eventsForThisDay.length > 0 ? (
              eventsForThisDay.map((_, index) => (
                <div key={index} className="event-dot" style={{ backgroundColor: 'blue' }}></div>
              ))
            ) : null;
          }}
        />
        <br/>
    <Button
  variant="contained"
  color="primary"
  className="add-event-button"
  onClick={() =>
    navigate('/agent/dashboard/bookingform', {
      state: { email:storedEmail, selectedDate: date, activeMenu: 'Booking Form' }, // Pass the selectedDate and activeMenu state
    })
  }
>
  Add Event
</Button>




      </div>
      <div className="divider"></div>
      <div className="events-section">
        <h2>Events for {date.toLocaleDateString()}</h2>
        {loading ? (
          <p>Loading events...</p>
        ) : error ? (
          <p>{error}</p>
        ) : events.length > 0 ? (
          <ul>
            {events.map((event, index) => (
              <li key={index} className="event-item">
                <strong>{event.bookingdetails.eventtype}</strong>
                <p>{event.bookingdetails.hallname}</p>
                <p>{event.bookingdetails.timefrom} - {event.bookingdetails.timeto}</p>
              </li>
            ))}
          </ul>
        ) : (
          <p className="no-events">No events for this day</p>
        )}
      </div>
    </div>
  );
};

export default AgentCalendar;
