import React, { useState, useEffect } from 'react';
import { Button } from '@mui/material'; // Importing Button from Material-UI
import { useNavigate, useLocation } from 'react-router-dom';  
import axios from 'axios'; 
import './AgentDashboardContent.css'; // Custom CSS file for styling

const AgentDashboardContent = () => {
  const [approvedEventsCount, setApprovedEventsCount] = useState(0); 
  const [recentBookings, setRecentBookings] = useState([]); // To store recent bookings
  const [totalBookingsCount, setTotalBookingsCount] = useState(0);
  const navigate = useNavigate(); 
  const location = useLocation();  // Access location object
  const { email } = location.state || {};  // Destructure email from location.state

  useEffect(() => {
    if (email) {
      localStorage.setItem('agentEmail', email); // Store email in localStorage
    }
  }, [email]);

  const storedEmail = email || localStorage.getItem('agentEmail');

  // Fetch approved events from the API
  useEffect(() => {
    const fetchApprovedEvents = async () => {
      try {
        const response = await axios.get('http://localhost:8000/api/v1/getBooking');
        console.log('API Response:', response.data);
  
        if (response.status === 200) {
          const bookings = response.data.bookings;
          console.log('Bookings:', bookings);
  
          if (Array.isArray(bookings)) {
            const today = new Date();
            today.setHours(0, 0, 0, 0); // Set today's date to midnight (ignore time)
            
            const approvedEvents = bookings.filter(booking => {
              const bookingDate = new Date(booking.bookingdetails.date);
              bookingDate.setHours(0, 0, 0, 0); // Set booking date to midnight (ignore time)
  
              console.log('Booking Date:', bookingDate);
              console.log('Booking Status:', booking.bookingStatus);
  
              return (
                booking.bookingStatus === 'approved' && bookingDate >= today
              );
            });
  
            console.log('Filtered Approved Events:', approvedEvents);
            setApprovedEventsCount(approvedEvents.length);
          } else {
            console.error('Bookings data is not an array.');
          }
        }
      } catch (error) {
        console.error('Error fetching events:', error);
      }
    };
  
    fetchApprovedEvents();
  }, []); 

  // Fetch recent bookings based on email
  useEffect(() => {
    const fetchRecentBookings = async () => {
      try {
        const response = await axios.get('http://localhost:8000/api/v1/getBooking');
        console.log('API Response:', response.data);
  
        if (response.status === 200) {
          const bookings = response.data.bookings;
          if (Array.isArray(bookings)) {
            const userBookings = bookings.filter(booking => booking.contactdetails.email === storedEmail);
            const totalBookingsCount = userBookings.length;
    
            const today = new Date();
            today.setHours(0, 0, 0, 0); // Set to midnight to ignore the time part
    
            const recentBookings = userBookings.filter(booking => {
              const bookingDate = new Date(booking.bookingdetails.date);
              bookingDate.setHours(0, 0, 0, 0);
              return bookingDate >= today;
            });
  
            console.log('User Bookings:', userBookings); 
            console.log('Filtered Recent Bookings:', recentBookings);
            console.log('Total Bookings Count:', totalBookingsCount);
  
            setRecentBookings(recentBookings);
            setTotalBookingsCount(totalBookingsCount);
          } else {
            console.error('Bookings data is not an array.');
          }
        }
      } catch (error) {
        console.error('Error fetching recent bookings:', error);
      }
    };
  
    if (storedEmail) {
      fetchRecentBookings();
    }
  }, [storedEmail]);
  

  return (
    <div className="dashboard-content">
      {/* Personalized welcome message */}
      <h3>Welcome, {email || 'Agent'}</h3>

      <div className="stats">
        <p>Total Bookings: <strong>{totalBookingsCount}</strong> 
          <Button href="/agent/dashboard/calendar">More details</Button>
        </p>
        <p>Upcoming Events: <strong>{approvedEventsCount}</strong> 
          <Button href="/agent/dashboard/calendar">View Calendar</Button>
        </p>
      </div>

      <h4>Recent Bookings</h4>
      <div className="recent-bookings">
  {recentBookings.length > 0 ? (
    recentBookings.map((booking, index) => (
      <p key={index}>
         Customer: {booking.contactdetails.firstname} {booking.contactdetails.lastname}, 
         Status: {booking.bookingStatus}, 
         Date: {new Date(booking.bookingdetails.date).toLocaleDateString()}
      </p>
    ))
  ) : (
    <p>No recent bookings available.</p>
  )}
</div>


      <div className="quick-actions">
        {/* Navigate to Booking Form */}
        <Button
          variant="contained"
          color="primary" 
          onClick={() =>
            navigate('/agent/dashboard/bookingform', {
              state: { email: storedEmail, activeMenu: 'Booking Form' },
            })
          }
        >
          Create New Booking
        </Button>
        <Button variant="outlined" color="secondary">
          View Customer Profiles
        </Button>
      </div>
    </div>
  );
};

export default AgentDashboardContent;
