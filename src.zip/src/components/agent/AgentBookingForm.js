import React, { useCallback, useEffect, useState } from 'react';
import axios from 'axios';
import { useLocation } from 'react-router-dom';
import './BookingDetails.css'

const AgentBookingForm = () => {
  const location = useLocation();
  const { email, role, userId } = location.state || {}; // Get userId here

  
  const [halls, setHalls] = useState([]);
  const [formData, setFormData] = useState({
    bookingtype: '',
    eventtype: '',
    hallname: [],
    noofguest: '',
    date: '',
    timefrom: '',
    timeto: '',
    interestservice: [],
    otherinformation: '',
    firstname: '',
    lastname: '',
    streetaddress: '',
    state: '',
    city: '',
    postcode: '',
    country: '',
    email: '',
    phoneno: '',
  });
  const [currentStep, setCurrentStep] = useState(1);
  const handleStepCompletion = (step) => {
    if (step === 1) {
      // Check if all required fields in the first flex-box are filled
      if (formData.bookingtype && formData.eventtype && formData.hallname.length && formData.noofguest && formData.date && formData.timefrom && formData.timeto) {
        setCurrentStep(2);
      } else {
        alert('Please complete all fields in Booking Details.');
      }
    } else if (step === 2) {
      // Check if the second step is complete
      if (formData.interestservice || formData.otherinformation) {
        setCurrentStep(3);
      } else {
        alert('Please select at least one service or add other information.');
      }
    }
    else if (step === 3) {
      // Check if the second step is complete
      if (formData.firstname.length && formData.lastname && formData.streetaddress && formData.state && formData.city && formData.postcode) {
        setCurrentStep(4);
      } else {
        alert('Please select at least one service or add other information.');
      }
    }
  };

  const fetchHalls = useCallback(async () => {
    try {
      const { data } = await axios.get('http://localhost:8000/api/v1/hall'); // Removed headers
      setHalls(data.halls); // Wrap state update in startTransition
    } catch (error) {
      console.error('Error fetching halls:', error);
      alert('Failed to fetch halls. Please try again.'); // Generic error handling
    }
  }, []);

  useEffect(() => {
    fetchHalls();
  }, [fetchHalls]);

  const [message, setMessage] = useState('');

  const eventTypes = [
    'Wedding', 'Reception', 'Social Gathering', 'Concert', 'Community Event', 'Birthday'
  ];

  const services = [
    'Tables and Chairs', 'Catering', 'Event Live Telecast',
    'Videography', 'Soft Drinks', 'Hall Decoration', 'Stage Decoration',
    'Waiters', 'DJ System'
  ];

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    if (type === 'checkbox') {
      if (checked) {
        setFormData((prevState) => ({
          ...prevState,
          [name]: [...prevState[name], value],
        }));
      } else {
        setFormData((prevState) => ({
          ...prevState,
          [name]: prevState[name].filter((item) => item !== value),
        }));
      }
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('http://localhost:8000/api/v1/bookingform/new', {
        bookingdetails: {
          bookingtype: formData.bookingtype,
          eventtype: formData.eventtype,
          hallname: formData.hallname.join(', '),
          noofguest: formData.noofguest,
          date: formData.date,
          timefrom: formData.timefrom,
          timeto: formData.timeto,
          interestservice: formData.interestservice.join(', '),
          otherinformation: formData.otherinformation,
        },
        contactdetails: {
          firstname: formData.firstname,
          lastname: formData.lastname,
          streetaddress: formData.streetaddress,
          state: formData.state,
          city: formData.city,
          postcode: formData.postcode,
          country: formData.country,
          email: formData.email || email, // Use email passed via state if not provided
          phoneno: formData.phoneno,
        },
        role: role,
        userId: userId // Include userId in the request
      });

      setMessage('Booking request sent successfully!');
      setFormData({}); // Reset form
    } catch (error) {
      if (error.response && error.response.data.message) {
        setMessage(error.response.data.message);
      } else {
        setMessage('Error in sending booking request.');
      }
    }
  };

  return (
    <div style={{ maxWidth: '100%', paddingLeft: '30px', backgroundColor: '#ffffff', borderRadius: '8px', boxShadow: '0 4px 8px rgba(0, 0, 0, 0.1)' }}>
      <h3>Booking Form</h3>
      <hr />

      <div className="form-container">
        <form onSubmit={handleSubmit} className="booking-form">
          <div className="form-row">

            <div className={`flex-box ${currentStep >= 1 ? '' : 'disabled'}`}>
              <h5><u>Booking Details</u></h5>
              <br />
              <label>
                <input
                  type="radio"
                  name="bookingtype"
                  value="Private"
                  onChange={handleChange}
                  required
                /> Private
              </label>
              <label>
                <input
                  type="radio"
                  name="bookingtype"
                  value="Organisation / Public"
                  onChange={handleChange}
                  required
                /> Organisation / Public
              </label>
              <label>Event Type</label>
              <select name="eventtype" onChange={handleChange} required>
                <option value="">Please Select</option>
                {eventTypes.map((event, index) => (
                  <option key={index} value={event}>{event}</option>
                ))}
              </select>
              <label>Hall Selection</label>
              {halls.map((hall, index) => (
                <label key={index}>
                  <input
                    type="checkbox"
                    name="hallname"
                    value={hall.name}
                    onChange={handleChange}
                  />
                  {hall.name}
                </label>
              ))}

              <label>Number of Guests</label>
              <input
                type="number"
                name="noofguest"
                value={formData.noofguest}
                onChange={handleChange}
                required
              />
              <label>Booking Date</label>
              <input
                type="date"
                name="date"
                value={formData.date}
                onChange={handleChange}
                required
              />
              <label>Time From</label>
              <input
                type="time"
                name="timefrom"
                value={formData.timefrom}
                onChange={handleChange}
                required
              />
              <label>Time To</label>
              <input
                type="time"
                name="timeto"
                value={formData.timeto}
                onChange={handleChange}
                required
              />
              <button type="button" onClick={() => handleStepCompletion(1)} className='next'>Next</button>
            </div>

            <div className={`flex-box ${currentStep >= 2 ? '' : 'disabled'}`}>
              <br /><br />
              <label>Interested Services</label>
              {services.map((service, index) => (
                <label key={index}>
                  <input
                    type="checkbox"
                    name="interestservice"
                    value={service}
                    onChange={handleChange}
                  />
                  {service}
                </label>
              ))}
              <label>Other Information</label>
              <textarea
                name="otherinformation"
                value={formData.otherinformation}
                onChange={handleChange}
              />
              <button type="button" onClick={() => handleStepCompletion(2)} className='next'>Next</button>
            </div>

            <div className={`flex-box ${currentStep >= 3 ? '' : 'disabled'}`}>
              <h5><u>Contact Details</u></h5>
              <br />
              <label>First Name</label>
              <input
                type="text"
                name="firstname"
                value={formData.firstname}
                onChange={handleChange}
                required
              />
              <label>Last Name</label>
              <input
                type="text"
                name="lastname"
                value={formData.lastname}
                onChange={handleChange}
                required
              />
              <label>Street Address</label>
              <input
                type="text"
                name="streetaddress"
                value={formData.streetaddress}
                onChange={handleChange}
                required
              />
              <label>State</label>
              <input
                type="text"
                name="state"
                value={formData.state}
                onChange={handleChange}
                required
              />
              <label>City</label>
              <input
                type="text"
                name="city"
                value={formData.city}
                onChange={handleChange}
                required
              />
              <label>Postcode</label>
              <input
                type="text"
                name="postcode"
                value={formData.postcode}
                onChange={handleChange}
                required
              />
              <button type="button" onClick={() => handleStepCompletion(3)} className='next'>Next</button>
            </div>

            <div className={`flex-box ${currentStep >= 4 ? '' : 'disabled'}`}>
              <br /><br />
              <label>Country</label>
              <input
                type="text"
                name="country"
                value={formData.country}
                onChange={handleChange}
                required
              />
              <label>Email</label>
              <input
                type="email"
                name="email"
                value={formData.email || email} // Pre-fill with email from location.state
                onChange={handleChange}
                required
              />
              <label>Phone Number</label>
              <input
                type="tel"
                name="phoneno"
                value={formData.phoneno}
                onChange={handleChange}
                required
              />
              <button type="submit" className="button">Submit</button>
            </div>
          </div>
        </form>
      </div>


    </div>

  );
};

export default AgentBookingForm;
