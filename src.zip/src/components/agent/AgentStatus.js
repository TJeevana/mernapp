import React, { useState, useEffect } from 'react';
import './BookingDetails.css';
import { useLocation } from 'react-router-dom';

function BookingDetails() {
  const [activeTab, setActiveTab] = useState('statusUpdate');
  const [bookingsData, setBookingsData] = useState([]);
  const [selectedBookingId,setSelectedBookingId]=useState(null)
  const [selectedBoundStatus, setSelectedBoundStatus] = useState('');
  const [BookingStatus, setSelectedBookingStatus] = useState('');
  const [showReasonBox, setShowReasonBox] = useState(false);
  const location = useLocation();
  const [selectedItems, setSelectedItems] = useState([]);
  const [discountCode, setDiscountCode] = useState('');
  const [totalQuotes, setTotalQuotes] = useState(0);
  const [discountApplied, setDiscountApplied] = useState(false);
  const [totalPayment, setTotalPayment] = useState(0);
  const [paymentStatus, setPaymentStatus] = useState(0);
  const [hallPayment, setHallPayment] = useState(0);
  const [describeEvent, setDescribeEvent] = useState('');
  const [additionalServices, setAdditionalServices] = useState('');
  const [otherInformation, setOtherInformation] = useState('');

  const packages = [
    { id: 1, name: "Package / Head - Palmyra Hall Tier 1", value: 100 },
    { id: 2, name: "Package / Head - Palmyra Hall Tier 2", value: 150 },
    { id: 3, name: "Package / Head - Eliezer Hall Tier 1", value: 120 },
    { id: 4, name: "Package / Head - Eliezer Hall Tier 2", value: 200 },
    { id: 5, name: "Hall Hire", value: 500 },
    { id: 6, name: "Catering", value: 300 },
    { id: 7, name: "Decoration", value: 250 },
    { id: 8, name: "Addons", value: 100 },
  ];

  const handleCheckboxChange = (e, item) => {
    const isChecked = e.target.checked;
    setSelectedItems(prevSelected => {
      if (isChecked) {
        setTotalQuotes(prevTotal => prevTotal + item.value);
        return [...prevSelected, item];
      } else {
        setTotalQuotes(prevTotal => prevTotal - item.value);
        return prevSelected.filter(i => i.id !== item.id);
      }
    });
  };

  const applyDiscount = () => {
    if (discountCode === 'DISCOUNT50' && !discountApplied) {
      setTotalQuotes(prevTotal => prevTotal * 0.5);
      setDiscountApplied(true);
    } else {
      alert('Invalid discount code or discount already applied.');
    }
  };

  const { userId } = location.state || {};

  useEffect(() => {
    const fetchBookingData = async () => {
      try {
        const response = await fetch('http://localhost:8000/api/v1/myBooking', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ userId }),
        });
        const data = await response.json();
        setBookingsData(data.bookings || []);
      } catch (error) {
        console.error('Error fetching booking data:', error);
      }
    };

    fetchBookingData();
  }, [userId]);

  useEffect(() => {
    setTotalPayment(totalQuotes + parseFloat(hallPayment));
  }, [totalQuotes, hallPayment]);

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  const handleBoundStatusChange = (e) => {
    const value = e.target.value;
    setSelectedBoundStatus(value);
    setShowReasonBox(value === 'fullyRefund' || value === 'partialRefund');
  };
  const handleBookingStatusChange = (e) => {
    const value = e.target.value;
    setSelectedBookingStatus(value);
  }
  const handlePaymentChange = (e) => {
    const value = e.target.value;
    setPaymentStatus(value);
  }

  const handleSubmitUpdates = async () => {
    let updatedData = {
      describeEvent,
      additionalServices,
      otherInformation,
      selectedBoundStatus,
      BookingStatus,
      selectedItems,
      paymentStatus,
      totalQuotes,
      totalPayment,
      hallPayment,
    };

    // Clean up empty fields from updatedData
    Object.keys(updatedData).forEach(key => {
      if (updatedData[key] === '' || (Array.isArray(updatedData[key]) && updatedData[key].length === 0)) {
        delete updatedData[key];
      }
    });

    alert(JSON.stringify(updatedData, null, 2)); // To display the structured data in alert

    if (Object.keys(updatedData).length > 0) {
      try {
        const response = await fetch(`http://localhost:8000/api/v1/booking/update/${bookingsData[0]._id}`, {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(updatedData),
          
        });
        const data = await response.json();
        console.log('Booking updated successfully:', data);
       
      } catch (error) {
        console.error('Error updating booking:', error);
      }
    } else {
      alert("No data to update.");
    }
  };

  const handleSelectBooking = (bookingId) => {
    setSelectedBookingId(bookingId);
    setActiveTab('bookingInfo'); // Set default tab to booking info once a booking is selected
  };

  if (!bookingsData.length) {
    return <p>Loading...</p>;
  }

  return (
    <div className="booking-container">
      {/* Booking Selection Dropdown */}
      <div className="booking-selection">
      <h3>Select a booking to view details:</h3>
    <ul>
      {bookingsData.map((booking) => (
        <li key={booking._id}>
          <p><strong>Booking ID:</strong> {booking._id}</p>
          <p><strong>Booking Type:</strong> {booking.bookingdetails.bookingtype}</p>
          <p><strong>Date:</strong> {new Date(booking.bookingdetails.date).toLocaleDateString()}</p>
          <button onClick={() => handleSelectBooking(booking._id)}>View Details</button>
        </li>
      ))}
    </ul>
      </div>
  
      {/* Ensure a booking is selected before displaying tabs */}
      {selectedBookingId && (
        <>
          <div className="tabs">
            <button onClick={() => handleTabChange('bookingInfo')} className={activeTab === 'bookingInfo' ? 'active' : ''}>
              Booking Info
            </button>
            <button onClick={() => handleTabChange('statusUpdate')} className={activeTab === 'statusUpdate' ? 'active' : ''}>
              Status Update
            </button>
            <button onClick={() => handleTabChange('quotes')} className={activeTab === 'quotes' ? 'active' : ''}>
              Quotes
            </button>
            <button onClick={() => handleTabChange('payments')} className={activeTab === 'payments' ? 'active' : ''}>
              Payments
            </button>
            <button onClick={() => handleTabChange('remarks')} className={activeTab === 'remarks' ? 'active' : ''}>
              Remarks
            </button>
          </div>
  
          {bookingsData.map((booking) => (
            booking._id === selectedBookingId && (
              <div key={booking._id} className="tab-content">
                {activeTab === 'bookingInfo' && (
                  <div className="booking-info-section">
                    <h3 className="booking-heading">Booking Info</h3>
                    <div className="booking-info-grid">
                      <div className="booking-info-item">
                        <p><strong>Booking ID:</strong> <span>{booking._id}</span></p>
                      </div>
                      <div className="booking-info-item">
                        <p><strong>Booking Type:</strong> <span>{booking.bookingdetails.bookingtype}</span></p>
                      </div>
                      <div className="booking-info-item">
                        <p><strong>Start Date:</strong> <span>{new Date(booking.bookingdetails.date).toLocaleDateString()}</span></p>
                      </div>
                      <div className="booking-info-item">
                        <p><strong>Start Time:</strong> <span>{booking.bookingdetails.timefrom}</span></p>
                      </div>
                      <div className="booking-info-item">
                        <p><strong>End Time:</strong> <span>{booking.bookingdetails.timeto}</span></p>
                      </div>
                      <div className="booking-info-item">
                        <p><strong>No. of Guests:</strong> <span>{booking.bookingdetails.noofguest}</span></p>
                      </div>
                      <div className="booking-info-item">
                        <p><strong>Phone Number:</strong> <span>{booking.contactdetails.phoneno}</span></p>
                      </div>
                      <div className="booking-info-item">
                        <p><strong>Hall Selection:</strong> <span>{booking.bookingdetails.hallname}</span></p>
                      </div>
                      <div className="booking-info-item">
                        <p><strong>First Name:</strong> <span>{booking.contactdetails.firstname}</span></p>
                      </div>
                      <div className="booking-info-item">
                        <p><strong>Last Name:</strong> <span>{booking.contactdetails.lastname}</span></p>
                      </div>
                      <div className="booking-info-item">
                        <p><strong>Email:</strong> <span>{booking.contactdetails.email}</span></p>
                      </div>
                    </div>
  
                    <div>
                      <label>Describe your event:</label>
                      <textarea
                        value={describeEvent}
                        onChange={(e) => setDescribeEvent(e.target.value)}
                        rows="3"
                        placeholder="Enter event description"
                      />
                    </div>
  
                    <div>
                      <label>Additional services you are interested in:</label>
                      <textarea
                        value={additionalServices}
                        onChange={(e) => setAdditionalServices(e.target.value)}
                        rows="3"
                        placeholder="Enter additional services"
                      />
                    </div>
  
                    <div>
                      <label>Any other information:</label>
                      <textarea
                        value={otherInformation}
                        onChange={(e) => setOtherInformation(e.target.value)}
                        rows="3"
                        placeholder="Enter any other information"
                      />
                    </div>
                  </div>
                )}
  
                {activeTab === 'statusUpdate' && (
                  <div>
                    <h3>Status Update</h3>
                    <label>Status Change Notes:</label>
                    <textarea rows="5" placeholder="Enter status update here..."></textarea>
                    <div className="dropdown">
                      <label>Bound Status:</label>
                      <select onChange={handleBoundStatusChange} value={selectedBoundStatus}>
                        <option value="unpaid">Unpaid</option>
                        <option value="fullyPaid">Fully Paid</option>
                        <option value="fullyRefund">Fully Refunded</option>
                        <option value="partiallyPaid">Partially Paid</option>
                        <option value="partialRefund">Partially Refunded</option>
                      </select>
                    </div>
                    {showReasonBox && (
                      <textarea placeholder="Enter reason for refund"></textarea>
                    )}
                    <div className="dropdown">
                      <label>Booking Status:</label>
                      <select onChange={handleBookingStatusChange} value={BookingStatus}>
                        <option value="cancelled">Cancelled</option>
                        <option value="Quote">Quote</option>
                        <option value="Confirm">Confirmed</option>
                        <option value="Withdrawn">Withdrawn</option>
                      </select>
                    </div>
                  </div>
                )}
  
                {activeTab === 'quotes' && (
                  <div>
                    <h3>Quotes</h3>
                    {packages.map((item) => (
                      <div key={item.id}>
                        <label>
                          <input
                            type="checkbox"
                            checked={selectedItems.some((i) => i.id === item.id)}
                            onChange={(e) => handleCheckboxChange(e, item)}
                          />
                          {item.name} - ${item.value}
                        </label>
                      </div>
                    ))}
                    <div>
                      <strong>Total Quotes: ${totalQuotes}</strong>
                    </div>
                    <div>
                      <label>Discount Code:</label>
                      <input
                        type="text"
                        value={discountCode}
                        onChange={(e) => setDiscountCode(e.target.value)}
                      />
                      <button onClick={applyDiscount}>Apply Discount</button>
                    </div>
                  </div>
                )}
  
                {activeTab === 'payments' && (
                  <div>
                    <h3>Payments</h3>
                    <div className="dropdown">
                      <label>Payment method:</label>
                      <select onChange={handlePaymentChange} value={paymentStatus}>
                        <option value="Deposit paid">Deposit paid</option>
                        <option value="unpaid">Unpaid</option>
                        <option value="fullyPaid">Fully Paid</option>
                        <option value="fullyRefund">Fully Refunded</option>
                        <option value="partiallyPaid">Partially Paid</option>
                        <option value="partialRefund">Partially Refunded</option>
                      </select>
                    </div>
                    <div>
                      <label>Hall Payment:</label>
                      <input
                        type="number"
                        value={hallPayment}
                        onChange={(e) => setHallPayment(e.target.value)}
                        placeholder="Enter hall payment amount"
                      />
                    </div>
                    <div>
                      <strong>Total Quotes: ${totalQuotes}</strong>
                    </div>
                    <div>
                      <strong>Total Payment: ${totalPayment}</strong>
                    </div>
                  </div>
                )}
  
                {activeTab === 'remarks' && (
                  <div>
                    <h3>Remarks</h3>
                    <textarea rows="5" placeholder="Enter remarks here..."></textarea>
                  </div>
                )}
  
                <button onClick={handleSubmitUpdates}>Submit Updates</button>
              </div>
            )
          ))}
        </>
      )}
    </div>
  );
}  

export default BookingDetails;
