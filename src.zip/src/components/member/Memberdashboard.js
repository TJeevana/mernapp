import React, { useEffect, useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import './Memberdashboard.css';
import axios from 'axios';
import UserNav from '../UserNav';
import BookingForm from './BookingForm'; // Assuming you already have this component
import BookingStatus from './BookingStatus'; // Assuming you already have this component
import ReviewForm from './ReviewForm'; // Import ReviewForm component

function Memberdashboard() {
  const location = useLocation();
  const { email, role, userId } = location.state || {}; // Get email, role, and userId from location state
  const navigate = useNavigate();
  const [error, setError] = useState(null); // State to handle errors
  const [hasBooked, setHasBooked] = useState(false); // State to track if the member has already booked
  const [activeForm, setActiveForm] = useState(null); // State to track the active form

  useEffect(() => {
    const checkBookingStatus = async () => {
      try {
        // API call to check if the user has booked
        const response = await axios.post(`http://localhost:8000/api/v1/booking/status`, { email, role, userId });

        if (response.data.success && response.data.booked) {
          setHasBooked(true); // Set hasBooked to true if the user has booked for the day
        }
      } catch (error) {
        console.error('Error fetching booking status:', error);
        setError('Failed to check booking status');
      }
    };

    if (role === 'member') {
      checkBookingStatus(); // Check booking status if the user is a member
    }
  }, [email, role, userId]); // Re-run the effect if email or role changes

  // Function to handle button clicks
  const handleButtonClick = (formType) => {
    setActiveForm(formType);
  };

  return (
    <div>
      <UserNav />

      {error && <p className="error">{error}</p>} {/* Show error if any */}

      <div className='container'>
        <div className='left-side'>
          {/* Left-side buttons */}
          <button
            className="member-button"
            onClick={() => handleButtonClick('bookingForm')} // Set active form to Booking Form
            disabled={role === 'member' && hasBooked}
          >
            {role === 'member' && hasBooked ? 'Already Booked Today' : 'Booking Form'}
          </button>

          <button
            className="member-button"
            onClick={() => handleButtonClick('bookingStatus')} // Set active form to Booking Status
          >
            Booking Status
          </button>

          <button
            className="member-button"
            onClick={() => handleButtonClick('review')} // Set active form to Review
          >
            Review
          </button>
        </div>

        <div className='right-side'>
          {/* Right-side dynamic content */}
          {activeForm === 'bookingForm' && (
            <BookingForm email={email} role={role} userId={userId} />
          )}
          {activeForm === 'bookingStatus' && (
            <BookingStatus email={email} role={role} userId={userId} />
          )}
          {activeForm === 'review' && (
            <ReviewForm email={email} role={role} userId={userId} />
          )}
        </div>
      </div>
    </div>
  );
}

export default Memberdashboard;
