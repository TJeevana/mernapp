import React, { useState } from 'react';
import axios from 'axios';
import { useLocation } from 'react-router-dom';
import './ReviewForm.css'; // Importing a CSS file for styling

const ReviewForm = () => {
  const [review, setReview] = useState(''); // Store the review text
  const [rating, setRating] = useState(0); // Store the rating
  const [error, setError] = useState(''); // For error messages
  const [successMessage, setSuccessMessage] = useState(''); // Success message after submission
  const location = useLocation();
  const { email, role, userId } = location.state || {}; // Get email and role from location state

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!review || rating === 0) {
      setError('Please provide a review and a rating.');
      return;
    }

    try {
      // Send POST request to submit the review
      const response = await axios.post('http://localhost:8000/api/v1/submitReview', { email, userId, review, rating });

      if (response.data.success) {
        setSuccessMessage('Review submitted successfully!');
        setReview(''); // Clear the review text field
        setRating(0); // Reset the rating
        setError('');
      } else {
        setError('Failed to submit review.');
      }
    } catch (err) {
      setError('Failed to submit review.');
    }
  };

  return (
    <div className="review-form-container">
      <h1>Write a Review</h1>
      {error && <p className="error">{error}</p>}
      {successMessage && <p className="success">{successMessage}</p>}
      
      <form onSubmit={handleSubmit}>
        <div className='form-group'>
            <label htmlFor='hall'>Hall:</label>
            <select id="hall">
            <option value={0}>Select the Hall</option>
            <option value={1}>1 - Poor</option>
            <option value={2}>2 - Fair</option>
            <option value={3}>3 - Good</option>
            <option value={4}>4 - Very Good</option>
            <option value={5}>5 - Excellent</option>
          </select>
        </div>
      <div className="form-group">
          <label htmlFor="rating">Rating:</label>
          <select
            id="rating"
            value={rating}
            onChange={(e) => setRating(Number(e.target.value))}
          >
            <option value={0}>Select a rating</option>
            <option value={1}>1 - Poor</option>
            <option value={2}>2 - Fair</option>
            <option value={3}>3 - Good</option>
            <option value={4}>4 - Very Good</option>
            <option value={5}>5 - Excellent</option>
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="review">Review:</label>
          <textarea
            id="review"
            value={review}
            onChange={(e) => setReview(e.target.value)}
            rows="4"
            placeholder="Write your review here..."
          />
        </div>
        
        

        <button type="submit">Submit Review</button>
      </form>
    </div>
  );
};

export default ReviewForm;
