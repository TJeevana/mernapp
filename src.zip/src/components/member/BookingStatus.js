import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useLocation } from 'react-router-dom';
import './BookingStatus.css'; // Importing a CSS file for styling

const BookingStatus = () => {
  const [bookings, setBookings] = useState([]);
  const [error, setError] = useState(''); // Initialize the error state
  const location = useLocation();
  const { email, role,userId} = location.state || {}; // Get email and role from location state

  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const response = await axios.post('http://localhost:8000/api/v1/myBooking', { email,userId });
        if (response.data && response.data.bookings) {
          setBookings(response.data.bookings);
        } else {
          setError('No bookings found.');
        }
      } catch (error) {
        setError('Failed to fetch bookings.');
      }
    };

    if (email) {
      fetchBookings();
    }
  }, [email,userId]);

  const handleDelete = async (id) => {
    if (window.confirm('Are you sure you want to delete this booking?')) {
      try {
        // Send the DELETE request
        const response = await axios.delete(`http://localhost:8000/api/v1/bookings/${id}`);
        
        if (response.data.success) {
          // Remove the deleted booking from the state
          setBookings(prevBookings => prevBookings.filter(booking => booking._id !== id));
        } else {
          setError('Failed to delete booking.');
        }
      } catch (err) {
        setError('Failed to delete booking.');
      }
    }
  };

  return (
    <div className="booking-status-container">
      <h1>Your Booking Status</h1>
      {error && <p className="error">{error}</p>}
      {Array.isArray(bookings) && bookings.length > 0 ? (
        bookings.map((booking) => (
          <div key={booking._id} className="booking-card">
            <h3>Event Type: {booking.bookingdetails.eventtype}</h3>
            <p>Date: {new Date(booking.bookingdetails.date).toLocaleDateString()}</p>
            <p>Time: {booking.bookingdetails.timefrom} - {booking.bookingdetails.timeto}</p>
            <p>Guests: {booking.bookingdetails.noofguest}</p>
            <p>Status: {booking.bookingStatus}</p>
            {booking.bookingStatus === 'Pending' && <p className="status-pending">Pending approval</p>}
            {booking.bookingStatus === 'approved' && <p className="status-approved">Approved! Your event is booked.</p>}
            {booking.bookingStatus === 'rejected' && <p className="status-rejected">Sorry, your booking was rejected.</p>}
            {/* Conditionally render the Delete button based on role */}
            {role !== 'member' && (
              <button onClick={() => handleDelete(booking._id)}>Delete</button>
            )}
          </div>
        ))
      ) : (
        <p>No bookings yet.</p>
      )}
      
    </div>
  );
};

export default BookingStatus;
