import React, { useCallback, useEffect, useState } from 'react';
import axios from 'axios';
import './BookingForm.css'; // Import the CSS file for styling
import { useLocation } from 'react-router-dom';

const BookingForm = () => {
  const location = useLocation();
  const { email, role, userId } = location.state || {}; // Get userId here

  const [halls, setHalls] = useState([]);
  const [formData, setFormData] = useState({
    bookingtype: '',
    eventtype: '',
    hallname: [],
    noofguest: '',
    date: '',
    timefrom: '',
    timeto: '',
    interestservice: [],
    otherinformation: '',
    firstname: '',
    lastname: '',
    streetaddress: '',
    state: '',
    city: '',
    postcode: '',
    country: '',
    email: '',
    phoneno: '',
  });

  const fetchHalls = useCallback(async () => {
    try {
      const { data } = await axios.get('http://localhost:8000/api/v1/hall'); // Removed headers
      setHalls(data.halls); // Wrap state update in startTransition
    } catch (error) {
      console.error('Error fetching halls:', error);
      alert('Failed to fetch halls. Please try again.'); // Generic error handling
    }
  }, []);

  useEffect(() => {
    fetchHalls();
  }, [fetchHalls]);

  const [message, setMessage] = useState('');

  const eventTypes = [
    'Wedding', 'Reception', 'Social Gathering', 'Concert', 'Community Event'
  ];

  const services = [
    'Tables and Chairs', 'Catering', 'Event Live Telecast', 
    'Videography', 'Soft Drinks', 'Hall Decoration', 'Stage Decoration', 
    'Waiters', 'DJ System'
  ];

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    if (type === 'checkbox') {
      if (checked) {
        setFormData((prevState) => ({
          ...prevState,
          [name]: [...prevState[name], value],
        }));
      } else {
        setFormData((prevState) => ({
          ...prevState,
          [name]: prevState[name].filter((item) => item !== value),
        }));
      }
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('http://localhost:8000/api/v1/bookingform/new', {
        bookingdetails: {
          bookingtype: formData.bookingtype,
          eventtype: formData.eventtype,
          hallname: formData.hallname.join(', '),
          noofguest: formData.noofguest,
          date: formData.date,
          timefrom: formData.timefrom,
          timeto: formData.timeto,
          interestservice: formData.interestservice.join(', '),
          otherinformation: formData.otherinformation,
        },
        contactdetails: {
          firstname: formData.firstname,
          lastname: formData.lastname,
          streetaddress: formData.streetaddress,
          state: formData.state,
          city: formData.city,
          postcode: formData.postcode,
          country: formData.country,
          email: formData.email || email, // Use email passed via state if not provided
          phoneno: formData.phoneno,
        },
        role: role,
        userId: userId // Include userId in the request
      });

      setMessage('Booking request sent successfully!');
      setFormData({}); // Reset form
    } catch (error) {
      if (error.response && error.response.data.message) {
        setMessage(error.response.data.message);
      } else {
        setMessage('Error in sending booking request.');
      }
    }
  };

  return (
    <div className="booking-form-container">
      <h1>Booking Form</h1>
      <hr />
      <h2>Booking Details</h2>
      {message && <p className="message">{message}</p>}
      <form onSubmit={handleSubmit} className="booking-form">
        <div className="form-group">
          <label>Booking Type</label>
          <label>
            <input
              type="radio"
              name="bookingtype"
              value="Private"
              onChange={handleChange}
              required
            /> Private
          </label>
          <label>
            <input
              type="radio"
              name="bookingtype"
              value="Organisation / Public"
              onChange={handleChange}
              required
            /> Organisation / Public
          </label>
        </div>

        <div className="form-group">
          <label>Event Type</label>
          <select name="eventtype" onChange={handleChange} required>
            <option value="">Please Select</option>
            {eventTypes.map((event, index) => (
              <option key={index} value={event}>{event}</option>
            ))}
          </select>
        </div>

        <div className="form-group">
          <label>Hall Selection</label>
          {halls.map((hall, index) => (
            <label key={index}>
              <input
                type="checkbox"
                name="hallname"
                value={hall.name} 
                onChange={handleChange}
              /> 
              {hall.name} 
            </label>
          ))}
        </div>

        <div className="form-group">
          <label>Number of Guests</label>
          <input
            type="number"
            name="noofguest"
            value={formData.noofguest}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Booking Date</label>
          <input
            type="date"
            name="date"
            value={formData.date}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Time From</label>
          <input
            type="time"
            name="timefrom"
            value={formData.timefrom}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Time To</label>
          <input
            type="time"
            name="timeto"
            value={formData.timeto}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Interested Services</label>
          {services.map((service, index) => (
            <label key={index}>
              <input
                type="checkbox"
                name="interestservice"
                value={service}
                onChange={handleChange}
              /> 
              {service}
            </label>
          ))}
        </div>

        <div className="form-group">
          <label>Other Information</label>
          <textarea
            name="otherinformation"
            value={formData.otherinformation}
            onChange={handleChange}
          />
        </div>

        <h2>Contact Details</h2>
        <div className="form-group">
          <label>First Name</label>
          <input
            type="text"
            name="firstname"
            value={formData.firstname}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Last Name</label>
          <input
            type="text"
            name="lastname"
            value={formData.lastname}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Street Address</label>
          <input
            type="text"
            name="streetaddress"
            value={formData.streetaddress}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>State</label>
          <input
            type="text"
            name="state"
            value={formData.state}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>City</label>
          <input
            type="text"
            name="city"
            value={formData.city}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Postcode</label>
          <input
            type="text"
            name="postcode"
            value={formData.postcode}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Country</label>
          <input
            type="text"
            name="country"
            value={formData.country}
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Email</label>
          <input
            type="email"
            name="email"
            value={formData.email || email} // Default to email passed via state
            onChange={handleChange}
            required
          />
        </div>

        <div className="form-group">
          <label>Phone Number</label>
          <input
            type="tel"
            name="phoneno"
            value={formData.phoneno}
            onChange={handleChange}
            required
          />
        </div>

        <button type="submit" className="button">Submit</button>
      </form>
    </div>
  );
};

export default BookingForm;
