//Home.js
import React, { Fragment } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../css/Home.css'; 
import MetaData from "./layouts/MetaData";
import img1 from '../images/img1.jpg';
import img2 from '../images/img2.jpg';
import img3 from '../images/img3.jpg';
import img4 from '../images/img4.jpg'; 
import img5 from '../images/img5.jpg'; 
import img6 from '../images/img6.jpg'; 
import img7 from '../images/img7.jpg'; 
import { Link } from 'react-router-dom'; 
//import UserNav from './UserNav';  
//import Footer from './Footer'; 
import { CardGroup, Card } from 'react-bootstrap';

 


const Home = () => {
  return (
    <Fragment> 
      <MetaData title={'Home'} />
    <div>
      {/* Image Carousel  */}
      <div id="carouselExampleIndicators" className="carousel slide" data-bs-ride="carousel" data-bs-interval="500">
        <div className="carousel-indicators">
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" className="active" aria-current="true" aria-label="Slide 1"></button>
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
          <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        <div className="carousel-inner">
          <div className="carousel-item active">
            <img src={img1} className="d-block w-100" alt="Slide 1" style={{ height: '400px', objectFit: 'cover' }} />
          </div>
          <div className="carousel-item">
            <img src={img2} className="d-block w-100" alt="Slide 2" style={{ height: '400px', objectFit: 'cover' }} />
          </div>
          <div className="carousel-item">
            <img src={img3} className="d-block w-100" alt="Slide 3" style={{ height: '400px', objectFit: 'cover' }} />
          </div>
        </div>
        <button className="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
          <span className="carousel-control-prev-icon" aria-hidden="true"></span>
          <span className="visually-hidden">Previous</span>
        </button>
        <button className="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
          <span className="carousel-control-next-icon" aria-hidden="true"></span>
          <span className="visually-hidden">Next</span>
        </button>
      </div>

      {/* Vision Text  */}
      <div className="text-center my-5">
        <h2>Our Vision</h2>
        <p>To establish an iconic landmark for the Tamils in Victoria that epitomizes 
            the Tamil consciousness that makes us all Tamil 
            Australians in our heart and preserves that kinship.</p>
      </div>
      {/* Button-more */}
      <div className="text-center my-4">
        <Link to="/about" className="btn" style={{ backgroundColor: 'orange', borderRadius: '20px', color: 'white' }}>
          More
        </Link>
      </div>
      <br/>

      {/* Cards */}
      <h4 style={{ fontFamily: 'Allura, cursive', margin: '0 520px', color:'#bd8351'}}><center> For Elegant Special Days</center></h4>
      <CardGroup className="mx-3 my-4"> 
        <Card className="mx-2"> 
          <Card.Img variant="top" src={img4} />
          <Card.Body>
            <Card.Title>Weddings & Receptions.</Card.Title>
          </Card.Body> 
        </Card>
        <Card className="mx-2">
          <Card.Img variant="top" src={img5} />
          <Card.Body>
            <Card.Title>Birthday Party & Private Function</Card.Title>
          </Card.Body>
        </Card>
        <Card className="mx-2">
          <Card.Img variant="top" src={img6} />
          <Card.Body>
            <Card.Title>Corporate Event & Meeting</Card.Title>  
          </Card.Body>
        </Card>
        <Card className="mx-2">
          <Card.Img variant="top" src={img7} />
          <Card.Body>
            <Card.Title>Community Event & Concerts</Card.Title>  
          </Card.Body>
        </Card>
      </CardGroup>
    </div>
    </Fragment>
  );
};

export default Home;
