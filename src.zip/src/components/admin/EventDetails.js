import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './ApprovedBookings.css'; // Import your CSS styles

const ApprovedBookings = () => {
    const [bookings, setBookings] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');

    useEffect(() => {
        const fetchBookings = async () => {
            try {
                const response = await axios.get('http://localhost:8000/api/v1/getBooking');
                const approvedBookings = response.data.bookings.filter(booking => booking.bookingStatus === 'approved');
                setBookings(approvedBookings);
            } catch (err) {
                setError('Failed to fetch bookings');
            } finally {
                setLoading(false);
            }
        };

        fetchBookings();
    }, []);

    const handleDelete = async (id) => {
        if (window.confirm('Are you sure you want to delete this booking?')) {
            try {
                await axios.delete(`http://localhost:8000/api/v1/bookings/${id}`);
                setBookings(prevBookings => prevBookings.filter(booking => booking._id !== id));
            } catch (err) {
                setError('Failed to delete booking');
            }
        }
    };

    const handleUpdate = async (id) => {
        // Here you would implement the logic to update a booking
        // For now, you can log the booking ID or prompt for new values
        const newStatus = window.prompt('Enter new booking status:'); // Example prompt to get new status
        if (newStatus) {
            try {
                await axios.put(`http://localhost:8000/api/v1/bookings/${id}`, { bookingStatus: newStatus });
                // Optionally, refetch bookings or update the state accordingly
                setBookings(prevBookings => 
                    prevBookings.map(booking => 
                        booking._id === id ? { ...booking, bookingStatus: newStatus } : booking
                    )
                );
            } catch (err) {
                setError('Failed to update booking');
            }
        }
    };

    if (loading) {
        return <p>Loading...</p>;
    }

    if (error) {
        return <p className="error-message">{error}</p>;
    }

    return (
        <div className="approved-bookings-container">
            <h1 className="approved-bookings-title">Event Details</h1>
            <hr></hr>
            {bookings.length === 0 ? (
                <p>No approved bookings found.</p>
            ) : (
                <ul className="approved-bookings-list">
                    {bookings.map(booking => (
                        <li key={booking._id} className="approved-booking-item">
                            <h2 className="approved-booking-subtitle">{booking.bookingdetails.eventtype}</h2>
                            <p className="approved-booking-detail">Date: {new Date(booking.bookingdetails.date).toLocaleDateString()}</p>
                            <p className="approved-booking-detail">Time: {booking.bookingdetails.timefrom} - {booking.bookingdetails.timeto}</p>
                            <p className="approved-booking-detail">Guests: {booking.bookingdetails.noofguest}</p>
                            <p className="approved-booking-detail">Contact: {booking.contactdetails.firstname} {booking.contactdetails.lastname}</p>
                            <p className="approved-booking-detail" style={{marginLeft:'73px'}}>{booking.contactdetails.email}</p>
                            <p className="approved-booking-detail" style={{marginLeft:'73px'}}>{booking.contactdetails.phoneno}</p>
                            <button onClick={() => handleUpdate(booking._id)}>Update</button>
                            <button onClick={() => handleDelete(booking._id)}>Delete</button>
                        </li>
                    ))}
                </ul>
            )}
        </div>
    );
};

export default ApprovedBookings;
