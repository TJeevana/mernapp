import React, { useEffect, useState, useCallback, startTransition } from 'react';
import axios from 'axios';
import { Button, Modal, Form } from 'react-bootstrap';
import Swal from 'sweetalert2';

const HallDetails = () => {
  const [halls, setHalls] = useState([]);
  const [showModal, setShowModal] = useState(false);
  const [modalType, setModalType] = useState('');
  const [selectedHall, setSelectedHall] = useState({});
  const [formData, setFormData] = useState({
    name: '',
    capacity: '',
    details: ''
  });

  // Fetch halls data from backend using useCallback
  const fetchHalls = useCallback(async () => {
    try {
      const { data } = await axios.get('http://localhost:8000/api/v1/hall'); // Removed headers
      startTransition(() => {
        setHalls(data.halls); // Wrap state update in startTransition
      });
    } catch (error) {
      console.error('Error fetching halls:', error);
      alert('Failed to fetch halls. Please try again.'); // Generic error handling
    }
  }, []);

  useEffect(() => {
    fetchHalls();
  }, [fetchHalls]);

  // Handle form input changes
  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Handle opening modal for create/edit
  const handleModalOpen = (type, hall = {}) => {
    setModalType(type);
    setSelectedHall(hall);
    if (type === 'edit') {
      setFormData({
        name: hall.name || '',
        capacity: hall.capacity || '',
        details: hall.details || ''
      });
    } else {
      setFormData({ name: '', capacity: '', details: '' });
    }
    setShowModal(true);
  };

  // Handle modal close
  const handleModalClose = () => setShowModal(false);

  // Handle create hall
  const handleCreateHall = async () => {
    try {
      await axios.post('http://localhost:8000/api/v1/hall/new', formData); // Removed headers
      startTransition(() => {
        fetchHalls(); // Refresh halls list
        setShowModal(false);
      });
    } catch (error) {
      console.error('Error creating hall:', error);
      alert('Failed to create hall. Please try again.'); // Generic error handling
    }
  };

  // Handle edit hall
  const handleEditHall = async () => {
    try {
      await axios.put(`http://localhost:8000/api/v1/hall/${selectedHall._id}`, formData); // Removed headers
      startTransition(() => {
        fetchHalls(); // Refresh halls list
        setShowModal(false);
      });
    } catch (error) {
      console.error('Error editing hall:', error);
      alert('Failed to update hall. Please try again.'); // Generic error handling
    }
  };

  // Handle delete hall
  const handleDeleteHall = async (hallId) => {
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'No, cancel!',
      reverseButtons: true
    }).then((result) => {
      if (result.isConfirmed) {
        axios
          .delete(`http://localhost:8000/api/v1/hall/${hallId}`) // Removed headers
          .then(() => {
            startTransition(() => {
              fetchHalls(); // Refresh halls list
              Swal.fire('Deleted!', 'The hall has been deleted.', 'success');
            });
          })
          .catch((error) => {
            console.error('Error deleting hall:', error);
            Swal.fire('Error', 'Failed to delete hall. Please try again.', 'error');
          });
      } else if (result.dismiss === Swal.DismissReason.cancel) {
        Swal.fire('Cancelled', 'The hall is safe :)', 'error');
      }
    });
  };

  return (
    <div style={{maxWidth:'100%',margin:'20px auto',padding:'20px',backgroundColor:'#ffffff',borderRadius:'8px',boxShadow:'0 4px 8px rgba(0, 0, 0, 0.1)'}}>
      <h2 style={{textAlign:'left'}}>Hall Details</h2>
      <hr/>
      <Button variant="primary" onClick={() => handleModalOpen('create')}>
        Create Hall
      </Button>

      <table className="table mt-3">
        <thead>
          <tr>
            <th>Name</th>
            <th>Capacity</th>
            <th>Details</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {halls.map((hall) => (
            <tr key={hall._id}>
              <td>{hall.name}</td>
              <td>{hall.capacity}</td>
              <td>{hall.details}</td>
              <td>
                <Button variant="warning" onClick={() => handleModalOpen('edit', hall)}>
                  Edit
                </Button>{' '}
                <Button variant="danger" onClick={() => handleDeleteHall(hall._id)}>
                  Delete
                </Button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* Create/Edit Modal */}
      <Modal show={showModal} onHide={handleModalClose}>
        <Modal.Header closeButton>
          <Modal.Title>{modalType === 'edit' ? 'Edit Hall' : 'Create Hall'}</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <Form>
            <Form.Group controlId="formBasicEmail">
              <Form.Label>Name</Form.Label>
              <Form.Control
                type="text"
                placeholder="Enter hall name"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                required
              />
            </Form.Group>

            <Form.Group controlId="formBasicCapacity">
              <Form.Label>Capacity</Form.Label>
              <Form.Control
                type="number"
                placeholder="Enter capacity"
                name="capacity"
                value={formData.capacity}
                onChange={handleInputChange}
                required
              />
            </Form.Group>

            <Form.Group controlId="formBasicDetails">
              <Form.Label>Details</Form.Label>
              <Form.Control
                as="textarea"
                rows={3}
                placeholder="Enter hall details"
                name="details"
                value={formData.details}
                onChange={handleInputChange}
                required
              />
            </Form.Group>
          </Form>
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleModalClose}>
            Close
          </Button>
          <Button variant="primary" onClick={modalType === 'edit' ? handleEditHall : handleCreateHall}>
            {modalType === 'edit' ? 'Update' : 'Create'}
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default HallDetails;
