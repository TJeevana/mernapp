import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './UserDetails.css';

const UserDetails = () => {
    const [users, setUsers] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    useEffect(() => {
        const fetchUsers = async () => {
            try {
                const { data } = await axios.get('http://localhost:8000/api/v1/users');
                console.log('Fetched users data:', data);
                setUsers(data.users);  // Assuming the users data is in the 'users' property
            } catch (error) {
                console.error('Error fetching users:', error);
                setError('Failed to fetch users. Please try again later.');
            } finally {
                setLoading(false);
            }
        };
        fetchUsers();
    }, []);

    // Approve agent request
    const handleApproveAgent = async (userId) => {
        console.log('Approving agent with userId:', userId);
        try {
            const { data } = await axios.put(`http://localhost:8000/api/v1/approveAgent/${userId}`);
            console.log('Agent approval response:', data);
            if (data.success) {
                alert('Agent approved successfully');
                // Update the UI with the new agent status
                setUsers(prevUsers =>
                    prevUsers.map(user =>
                        user._id === userId
                            ? { ...user, agentRequested: false, agentApproved: true }
                            : user
                    )
                );
            } else {
                alert('Failed to approve agent');
            }
        } catch (error) {
            console.error('Error approving agent:', error.response || error.message);
            alert('An error occurred while approving the agent. Please try again.');
        }
    };
    
    
    
    
    

    const handleRejectAgent = async (userId) => {
        try {
            // Wait for the backend response to ensure the user is deleted
            const { data } = await axios.put(`http://localhost:8000/api/v1/rejectAgent/${userId}`);
            console.log('Agent rejection response:', data);
    
            if (data.success) {
                alert('Agent request rejected and user deleted');
                // Update state to remove the rejected user from the UI
                setUsers((prevUsers) =>
                    prevUsers.filter(user => user._id !== userId) // Remove the rejected user
                );
            } else {
                alert('Failed to reject agent');
            }
        } catch (error) {
            console.error('Error rejecting agent:', error);
            alert('Failed to reject agent');
        }
    };
    

// Handle role change
const handleChangeRole = async (userId, newRole) => {
    try {
        // Prepare the payload for updating the role
        const payload = newRole === 'agent' ? { role: newRole, agentApproved: true } : { role: newRole };
        const { data } = await axios.put(`http://localhost:8000/api/v1/updateUserRole/${userId}`, payload);
        console.log('Role update response:', data);

        if (data.success) {
            alert('User role updated');
            setUsers((prevUsers) =>
                prevUsers.map(user =>
                    user._id === userId
                        ? { ...user, role: newRole, agentApproved: newRole === 'agent' ? true : user.agentApproved }
                        : user
                )
            );
        } else {
            alert('Failed to update role');
        }
    } catch (error) {
        console.error('Error updating user role:', error);
        alert('Failed to update role');
    }
};

    
    

    // Loading and error checks
    if (loading) return <div>Loading users...</div>;
    if (error) return <div>{error}</div>;

    return (
        <div className="user-details-container">
            <h1>User Management</h1>
            <table className="user-table">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Requested Role</th> {/* Updated Column */}
                        <th>Change Role</th> {/* Updated Column */}
                        <th>Actions</th> {/* New column for approve/reject */}
                    </tr>
                </thead>
                <tbody>
                    {users.length === 0 ? (
                        <tr><td colSpan="6">No users available</td></tr>
                    ) : (
                        users.map(user => (
                            <tr key={user._id}>
                                <td>{user.username}</td>
                                <td>{user.email}</td>
                                <td className={`role ${user.role}`}>{user.role}</td>
                                
                                {/* Requested Role Column */}
                                <td>
                                    {user.role === "agent" && !user.agentApproved 
                                        ? "Agent (Pending Approval)" 
                                        : user.requestedRole || 'No Request'}
                                </td>

                                {/* Change Role Column */}
                                <td>
                                    <select 
                                        onChange={(e) => handleChangeRole(user._id, e.target.value)} 
                                        value={user.role}
                                    >
                                        <option value="member">Member</option>
                                        <option value="agent">Agent</option>
                                        <option value="admin">Admin</option>
                                    </select>
                                </td>

                                {/* Actions Column */}
                                <td>
                                    {user.role === "agent" && !user.agentApproved && (
                                        <>
                                            <button onClick={() => handleApproveAgent(user._id)}>Approve</button>
                                            <button onClick={() => handleRejectAgent(user._id)}>Reject</button>
                                        </>
                                    )}
                                </td>
                            </tr>
                        ))
                    )}
                </tbody>
            </table>
        </div>
    );
};

export default UserDetails;
