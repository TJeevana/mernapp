import React, { useEffect, useState } from 'react';
import axios from 'axios';
import './AdminBookingStatus.css'; // Importing the CSS file for styling

const BookingDetails = () => {
  const [bookings, setBookings] = useState([]);
  const [error, setError] = useState('');
  const [updateMessage, setUpdateMessage] = useState('');
  const [role, setRole] = useState('');  // To handle the role (agent/member)

  // Fetch bookings based on role (member or agent)
  useEffect(() => {
    const fetchBookings = async () => {
      try {
        const response = await axios.get('http://localhost:8000/api/v1/getBooking');
        
        // Filter bookings based on the role of the user
        const filteredBookings = response.data.bookings.filter(booking => {
          // If the role is 'agent', filter bookings accordingly (could be bookings for agents to handle)
          return booking.bookingStatus === 'Pending' && (booking.role === 'agent' || booking.role === 'member');
        });
        
        setBookings(filteredBookings);
        
        // Clear message if no pending bookings
        if (filteredBookings.length === 0) {
          setUpdateMessage('No pending bookings available.');
        } else {
          setUpdateMessage('');  // Clear message if there are pending bookings
        }
      } catch (error) {
        setError('Failed to fetch bookings');
      }
    };

    fetchBookings();
  }, [role]); // Re-fetch if role changes

  // Function to update booking status (Approve or Reject)
  const updateBookingStatus = async (id, status) => {
    try {
      const response = await axios.put(`http://localhost:8000/api/v1/bookings/${id}`, {
        bookingStatus: status,
      });

      if (response.data.success) {
        setUpdateMessage(`Booking ${id} has been ${status}`);

        // Update the local state to reflect the change immediately
        if (status === 'approved') {
          setBookings((prevBookings) =>
            prevBookings.filter((booking) => booking._id !== id)
          );
        } else {
          setBookings((prevBookings) =>
            prevBookings.map((booking) =>
              booking._id === id ? { ...booking, bookingStatus: status } : booking
            )
          );
        }

        // Clear the update message after 3 seconds
        setTimeout(() => {
          setUpdateMessage('');
        }, 3000);
      }
    } catch (error) {
      setUpdateMessage('Failed to update booking status');
    }
  };

  return (
    <div className="admin-booking-status-container">
      <h1 style={{ textAlign: 'left' }}>Manage All Pending Bookings</h1>
      <hr />
      {error && <p className="error">{error}</p>}
      {updateMessage && <p className="update-message">{updateMessage}</p>}

      {Array.isArray(bookings) && bookings.length > 0 ? (
        bookings.map((booking) => (
          <div key={booking._id} className="admin-booking-card">
            <h3>Event Type: {booking.bookingdetails.eventtype}</h3>
            <h3>Name: {booking.contactdetails.firstname} {booking.contactdetails.lastname}</h3>
            <p>Date: {new Date(booking.bookingdetails.date).toLocaleDateString()}</p>
            <p>Time: {booking.bookingdetails.timefrom} - {booking.bookingdetails.timeto}</p>
            <p>Guests: {booking.bookingdetails.noofguest}</p>
            <p>Status: {booking.bookingStatus}</p>
            <p>Role: {booking.role}</p>

            <div className="admin-actions">
              {/* Show Approve and Reject buttons only if the booking is pending */}
              {booking.bookingStatus === 'Pending' && (
                <>
                  <button
                    className="approve-btn"
                    onClick={() => updateBookingStatus(booking._id, 'approved')}
                  >
                    Approve
                  </button>
                  <button
                    className="reject-btn"
                    onClick={() => updateBookingStatus(booking._id, 'rejected')}
                  >
                    Reject
                  </button>
                </>
              )}
            </div>
          </div>
        ))
      ) : (
        <p>No pending bookings available.</p>
      )}
    </div>
  );
};

export default BookingDetails;
