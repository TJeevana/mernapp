import React, { useEffect, useState } from 'react';
import { Link, Route, Routes, useLocation, useNavigate } from 'react-router-dom';
import { FaUserCircle, FaCalendarAlt, FaBuilding, FaClipboardList, FaUsers, FaEnvelope, FaSignOutAlt } from 'react-icons/fa';

// Lazy-loaded components
const HallDetails = React.lazy(() => import('./HallDetails'));
const BookingDetailsRequest = React.lazy(() => import('./BookingDetails'));
const EventDetails = React.lazy(() => import('./EventDetails'));
const UserDetails = React.lazy(() => import('./UserDetails'));
const AgentRequest = React.lazy(() => import('./AgentBooking'));
const Admincalendar = React.lazy(() => import('./Admincalendar'));

const Admindashboard = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const isActive = (path) => location.pathname.includes(path);

  // State to track event notifications
  const [bookingRequestEvent, setBookingRequestEvent] = useState(false);
  const [agentRequestEvent, setAgentRequestEvent] = useState(false);

  // Example function to simulate checking for new requests
  const checkForNewRequests = async () => {
    try {
      // Fetch booking data here (replace with your actual API request)
      const response = await fetch('http://localhost:8000/api/v1/getBooking');
      const data = await response.json();

      // Filter pending bookings
      const pendingBookings = data.bookings.filter(booking => booking.bookingStatus === 'Pending');
      setBookingRequestEvent(pendingBookings.length > 0); // Set true if there are pending bookings

      // Simulate checking for agent requests (adjust with actual API data)
      const agentRequests = data.agentRequests || []; // Adjust based on actual data structure
      setAgentRequestEvent(agentRequests.length > 0); // Set true if there are agent requests
    } catch (error) {
      console.error('Error fetching booking data:', error);
    }
  };

  const handleBookingApproval = async (bookingId) => {
    try {
      // Simulate API call to approve the booking
      const response = await fetch(`http://localhost:8000/api/v1/approveBooking/${bookingId}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
      });
      const result = await response.json();

      if (result.success) {
        // If booking is approved, remove the notification (update state)
        setBookingRequestEvent(false);
        // Optionally, you can re-fetch the bookings to ensure that the status is updated in real time
        checkForNewRequests();
      } else {
        console.error('Failed to approve the booking');
      }
    } catch (error) {
      console.error('Error approving the booking:', error);
    }
  };

  useEffect(() => {
    // Check for new requests when the dashboard loads
    checkForNewRequests();
    
    // Navigate to Calendar by default on first render
    if (location.pathname === '/admin/dashboard') {
      navigate('/admin/dashboard/calendar');
    }
  }, [location.pathname, navigate]);

  return (
    <div className="d-flex">
      {/* Sidebar */}
      <div
        className="text-white sidebar p-4 shadow-sm"
        style={{ backgroundColor: '#343a40', width: '260px', minHeight: '100vh', position: 'fixed' }}
      >
        {/* Admin Header */}
        <div className="text-center mb-4">
          <FaUserCircle size={80} className="mb-2" />
          <h4 style={{ color: '#b88a18', marginTop: '20px' }}>Admin Panel</h4>
        </div>

        {/* Navigation Items */}
        <ul className="nav flex-column">
          <li className="nav-item mb-3">
            <Link
              to="/admin/dashboard/calendar"
              className={`nav-link d-flex align-items-center ${isActive('calendar') ? 'active' : ''}`}
              style={{ backgroundColor: isActive('calendar') ? '#b88a18' : 'transparent', color: '#ffffff' }}
            >
              <FaCalendarAlt className="me-2" /> Calendar
            </Link>
          </li>
          <li className="nav-item mb-3">
            <Link
              to="/admin/dashboard/hall-details"
              className={`nav-link d-flex align-items-center ${isActive('hall-details') ? 'active' : ''}`}
              style={{ backgroundColor: isActive('hall-details') ? '#b88a18' : 'transparent', color: '#ffffff' }}
            >
              <FaBuilding className="me-2" /> Hall Details
            </Link>
          </li>
          <li className="nav-item mb-3">
            <Link
              to="/admin/dashboard/booking-details-request"
              className={`nav-link d-flex align-items-center ${isActive('booking-details-request') ? 'active' : ''}`}
              style={{ backgroundColor: isActive('booking-details-request') ? '#b88a18' : 'transparent', color: '#ffffff' }}
            >
              <FaClipboardList className="me-2" /> Booking Requests
              {bookingRequestEvent && <span className="badge bg-danger ms-2">New</span>}
            </Link>
          </li>
          <li className="nav-item mb-3">
            <Link
              to="/admin/dashboard/event-details"
              className={`nav-link d-flex align-items-center ${isActive('event-details') ? 'active' : ''}`}
              style={{ backgroundColor: isActive('event-details') ? '#b88a18' : 'transparent', color: '#ffffff' }}
            >
              <FaCalendarAlt className="me-2" /> Event Details
            </Link>
          </li>
          <li className="nav-item mb-3">
            <Link
              to="/admin/dashboard/user-details"
              className={`nav-link d-flex align-items-center ${isActive('user-details') ? 'active' : ''}`}
              style={{ backgroundColor: isActive('user-details') ? '#b88a18' : 'transparent', color: '#ffffff' }}
            >
              <FaUsers className="me-2" /> User Details
            </Link>
          </li>
          <li className="nav-item mb-3">
            <Link
              to="/admin/dashboard/agent-request"
              className={`nav-link d-flex align-items-center ${isActive('agent-request') ? 'active' : ''}`}
              style={{ backgroundColor: isActive('agent-request') ? '#b88a18' : 'transparent', color: '#ffffff' }}
            >
              <FaEnvelope className="me-2" /> Agent Requests
              {agentRequestEvent && <span className="badge bg-danger ms-2">New</span>}
            </Link>
          </li>
        </ul>

        {/* Sidebar Footer */}
        <div className="mt-auto text-center pt-3">
          <Link
            to="/"
            className="text-white text-decoration-none d-flex align-items-center justify-content-center"
          >
            <FaSignOutAlt className="me-2" /> Logout
          </Link>
        </div>
      </div>

      {/* Main Content */}
      <div
        className="content flex-grow-1 p-4"
        style={{ marginLeft: '260px', backgroundColor: '#f8f9fa', minHeight: '100vh' }}
      >
        <Routes>
          <Route path="hall-details" element={<HallDetails />} />
          <Route path="booking-details-request" element={<BookingDetailsRequest />} />
          <Route path="event-details" element={<EventDetails />} />
          <Route path="user-details" element={<UserDetails />} />
          {/*<Route path="agent-request" element={<AgentRequest />} />*/}
          <Route path="calendar" element={<Admincalendar />} />
        </Routes>
      </div>
    </div>
  );
};

export default Admindashboard;
