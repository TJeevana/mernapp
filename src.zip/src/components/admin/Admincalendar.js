import React, { useState, useEffect } from 'react';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';
import interactionPlugin from '@fullcalendar/interaction';
import axios from 'axios';
import Tooltip from '@mui/material/Tooltip';
import './Admincalendar.css';

const Admincalendar = () => {
  const [events, setEvents] = useState([]);
  const [clickedDateEvents, setClickedDateEvents] = useState([]);
  const [selectedDate, setSelectedDate] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isOverlayOpen, setIsOverlayOpen] = useState(false);  // State to control the overlay

  useEffect(() => {
    // Fetch approved bookings
    const fetchApprovedBookings = async () => {
      try {
        const { data } = await axios.get('http://localhost:8000/api/v1/getBooking');
        const approvedBookings = data.bookings.filter(booking => booking.bookingStatus === 'approved');
        
        // Map fetched bookings to the event format expected by FullCalendar
        const fetchedEvents = approvedBookings.map(booking => ({
          title: booking.bookingdetails.eventtype,
          hall: booking.bookingdetails.hallname,
          timefrom: booking.bookingdetails.timefrom,
          timeto: booking.bookingdetails.timeto,
          start: booking.bookingdetails.date,
          end: booking.bookingdetails.date,
          color: getEventColor(booking.bookingdetails.eventtype),
        }));

        setEvents(fetchedEvents);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching approved bookings:', error);
        setError('Failed to load bookings. Please try again later.');
        setLoading(false);
      }
    };

    fetchApprovedBookings();
  }, []);

  const getEventColor = (eventType) => {
    const colors = {
      Wedding: '#ff6f61',
      Reception: '#ffc107',
      'Social Gathering': '#28a745',
      Concert: '#17a2b8',
      'Community Event': '#6c757d',
      Birthday: '#fd7e14',
    };
    return colors[eventType] || '#007bff'; // Default color
  };

  const handleDateClick = (info) => {
    const clickedDate = new Date(info.dateStr).toISOString().split('T')[0];
    const eventsOnDate = events.filter(event => {
      const eventDate = new Date(event.start).toISOString().split('T')[0];
      return eventDate === clickedDate;
    });

    setSelectedDate(info.dateStr);
    setClickedDateEvents(eventsOnDate);
    setIsOverlayOpen(true);  // Open the overlay when a date is clicked
  };

  const closeOverlay = () => {
    setIsOverlayOpen(false); // Close the overlay
    setClickedDateEvents([]); // Clear events when overlay is closed
  };

  return (
    <div className="admin-calendar-page">
      {/* Overlay Page for Event Details */}
      {isOverlayOpen && (
        <div className="overlay-page">
          <div className="overlay-content">
            {selectedDate && clickedDateEvents.length > 0 && (
              <div className="event-details-section">
                <h4>Events on {new Date(selectedDate).toLocaleDateString()}</h4>
                {clickedDateEvents.map((event, index) => (
                  <div key={index} className="event-item" style={{ borderLeft: `5px solid ${event.color}` }}>
                    <div className="event-header" style={{ backgroundColor: event.color, color: '#fff' }}>
                      {event.title}
                    </div>
                    <div className="event-details">
                      <p><strong>Hall:</strong> {event.hall}</p>
                      <p><strong>Time:</strong> {event.timefrom} - {event.timeto}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
            <button className="close-overlay" onClick={closeOverlay}>Close</button>
          </div>
        </div>
      )}

      {/* Calendar Layout Section */}
      <div className="calendar-layout">
        <div className="calendar-container">
          <ul>
            <li><span className="legend-color" style={{ backgroundColor: '#ff6f61' }}></span> Wedding</li>
            <li><span className="legend-color" style={{ backgroundColor: '#ffc107' }}></span> Reception</li>
            <li><span className="legend-color" style={{ backgroundColor: '#28a745' }}></span> Social Gathering</li>
            <li><span className="legend-color" style={{ backgroundColor: '#17a2b8' }}></span> Concert</li>
            <li><span className="legend-color" style={{ backgroundColor: '#6c757d' }}></span> Community Event</li>
            <li><span className="legend-color" style={{ backgroundColor: '#fd7e14' }}></span> Birthday</li>
          </ul>
          {loading ? (
            <p>Loading bookings...</p>
          ) : error ? (
            <p>{error}</p>
          ) : (
            <FullCalendar
              plugins={[dayGridPlugin, interactionPlugin]}
              initialView="dayGridMonth"
              headerToolbar={{
                left: 'prev,next,today',
                center: 'title',
                right: 'dayGridMonth,dayGridWeek,dayGridDay',
              }}
              events={events}  // Pass the events to FullCalendar
              dateClick={handleDateClick}
              dayCellContent={(info) => {
                const eventColorsOnDate = events
                  .filter(event => new Date(event.start).toISOString().split('T')[0] === info.dateStr)
                  .map(event => event.color);

                return (
                  <div style={{ position: 'relative', cursor: 'pointer' }}>
                    <Tooltip title="Click for more details" arrow placement="top">
                      <div>{info.dayNumberText}</div>
                    </Tooltip>
                    <div style={{ display: 'flex', justifyContent: 'center', marginTop: '5px' }}>
                      {eventColorsOnDate.map((color, index) => (
                        <span
                          key={index}
                          style={{
                            width: '8px',
                            height: '8px',
                            borderRadius: '50%',
                            backgroundColor: color,
                            margin: '0 2px',
                          }}
                        ></span>
                      ))}
                    </div>
                  </div>
                );
              }}
            />
          )}
        </div>
      </div>

      {/* Events List on the Right */}
      <div className="events-list-container">
        <h4>Upcoming Events</h4>
        <div className="events-list">
          {events.length > 0 ? (
            events.map((event, index) => (
              <div key={index} className="event-item" style={{ borderLeft: `5px solid ${event.color}` }}>
                <div className="event-header" style={{ backgroundColor: event.color, color: '#fff' }}>
                  {event.title}
                </div>
                <div className="event-details">
                  <p><strong>Hall:</strong> {event.hall}</p>
                  <p><strong>Time:</strong> {event.timefrom} - {event.timeto}</p>
                </div>
              </div>
            ))
          ) : (
            <p>No events found</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default Admincalendar;
