import React, { useState, useEffect } from 'react';
import './BookingDetails.css';
import { useLocation } from 'react-router-dom';

function BookingDetails() {
  const [activeTab, setActiveTab] = useState('statusUpdate');
  const [bookingsData, setBookingsData] = useState([]);
  const location = useLocation();
  const { userId } = location.state || {};

  useEffect(() => {
    const fetchBookingData = async () => {
      try {
        const response = await fetch('http://localhost:8000/api/v1/myBooking', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ userId }),
        });
        const data = await response.json();
        setBookingsData(data.bookings || []);
      } catch (error) {
        console.error('Error fetching booking data:', error);
      }
    };

    fetchBookingData();
  }, [userId]);

  const handleTabChange = (tab) => {
    setActiveTab(tab);
  };

  if (!bookingsData.length) {
    return <p>Loading...</p>;
  }

  return (
    <div className="booking-container">
      <div className="tabs">
        <button onClick={() => handleTabChange('bookingInfo')} className={activeTab === 'bookingInfo' ? 'active' : ''}>
          Booking Info
        </button>
        <button onClick={() => handleTabChange('statusUpdate')} className={activeTab === 'statusUpdate' ? 'active' : ''}>
          Status Update
        </button>
        <button onClick={() => handleTabChange('quotes')} className={activeTab === 'quotes' ? 'active' : ''}>
          Quotes
        </button>
        <button onClick={() => handleTabChange('payments')} className={activeTab === 'payments' ? 'active' : ''}>
          Payments
        </button>
        <button onClick={() => handleTabChange('remarks')} className={activeTab === 'remarks' ? 'active' : ''}>
          Remarks
        </button>
      </div>

      {bookingsData.map((booking) => (
        <div key={booking._id} className="tab-content">
          {activeTab === 'bookingInfo' && (
            <div className="booking-info-section">
              <h3 className="booking-heading">Booking Info</h3>
              <div className="booking-info-grid">
                <div className="booking-info-item">
                  <p><strong>Booking ID:</strong> <span>{booking._id}</span></p>
                </div>
                <div className="booking-info-item">
                  <p><strong>Booking Type:</strong> <span>{booking.bookingdetails.bookingtype}</span></p>
                </div>
                <div className="booking-info-item">
                  <p><strong>Start Date:</strong> <span>{new Date(booking.bookingdetails.date).toLocaleDateString()}</span></p>
                </div>
                <div className="booking-info-item">
                  <p><strong>Start Time:</strong> <span>{booking.bookingdetails.timefrom}</span></p>
                </div>
                <div className="booking-info-item">
                  <p><strong>End Time:</strong> <span>{booking.bookingdetails.timeto}</span></p>
                </div>
                <div className="booking-info-item">
                  <p><strong>No. of Guests:</strong> <span>{booking.bookingdetails.noofguest}</span></p>
                </div>
                <div className="booking-info-item">
                  <p><strong>Phone Number:</strong> <span>{booking.contactdetails.phoneno}</span></p>
                </div>
                <div className="booking-info-item">
                  <p><strong>Hall Selection:</strong> <span>{booking.bookingdetails.hallname}</span></p>
                </div>
                <div className="booking-info-item">
                  <p><strong>First Name:</strong> <span>{booking.contactdetails.firstname}</span></p>
                </div>
                <div className="booking-info-item">
                  <p><strong>Last Name:</strong> <span>{booking.contactdetails.lastname}</span></p>
                </div>
                <div className="booking-info-item">
                  <p><strong>Email:</strong> <span>{booking.contactdetails.email}</span></p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'statusUpdate' && (
            <div>
              <h3>Status Update</h3>
              <div>
                <p><strong>Bound Status:</strong> {booking.bookingdetails.boundStatus}</p>
              </div>
              <div>
                <p><strong>Booking Status:</strong> {booking.bookingdetails.bookingStatus}</p>
              </div>
            </div>
          )}

          {activeTab === 'quotes' && (
            <div>
              <h3>Quotes</h3>
              <div>
                <p><strong>Total Quotes:</strong> ${booking.totalQuotes}</p>
              </div>
              {booking.selectedItems && booking.selectedItems.map((item) => (
                <div key={item.id}>
                  <p><strong>{item.name}:</strong> ${item.value}</p>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'payments' && (
            <div>
              <h3>Payments</h3>
              <div>
                <p><strong>Total Payment:</strong> ${booking.totalPayment}</p>
              </div>
              <div>
                <p><strong>Payment Status:</strong> {booking.paymentStatus}</p>
              </div>
              <div>
                <p><strong>Hall Payment:</strong> ${booking.hallPayment}</p>
              </div>
            </div>
          )}

          {activeTab === 'remarks' && (
            <div>
              <h3>Remarks</h3>
              <p>{booking.remarks}</p>
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

export default BookingDetails;
