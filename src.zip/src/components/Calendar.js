import React, { useState, useEffect } from 'react';
import FullCalendar from '@fullcalendar/react'; 
import dayGridPlugin from '@fullcalendar/daygrid'; 
import interactionPlugin from '@fullcalendar/interaction'; 
import axios from 'axios';
import '../css/Calendar.css'; 
import Tooltip from '@mui/material/Tooltip'; 
import Modal from 'react-bootstrap/Modal'; 
import Button from 'react-bootstrap/Button'; 

const Calendar = () => {
  const [events, setEvents] = useState([]);
  const [hoveredDate, setHoveredDate] = useState(null); 
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [selectedEvent, setSelectedEvent] = useState(null); // Store selected event
  const [showModal, setShowModal] = useState(false); // Modal state

  // Fetch events from the backend
  useEffect(() => {
    const fetchEvents = async () => {
      try {
        const { data } = await axios.get('http://localhost:8000/api/v1/getBooking');
        const approvedBookings = data.bookings.filter(booking => booking.bookingStatus === 'approved');
        const fetchedEvents = approvedBookings.map(event => ({
          title: event.bookingdetails.eventtype, // Event title
          hall: event.bookingdetails.hallname, // Hall name
          start: event.bookingdetails.date, // Event start date
          end: event.bookingdetails.date, // Event end date
          className: 'approved-event' // Custom class for styling approved events
        }));
        setEvents(fetchedEvents);
        setLoading(false);
      } catch (error) {
        console.error('Error fetching events:', error);
        setError('Failed to load events. Please try again later.');
        setLoading(false);
      }
    };
    fetchEvents();
  }, []);

  // Handle date hover
  const handleMouseEnter = (info) => {
    setHoveredDate(info.dateStr);
  };

  const handleMouseLeave = () => {
    setHoveredDate(null); 
  };

  // Handle date click to show modal with event details
  const handleDateClick = (info) => {
    const clickedDate = new Date(info.dateStr).toISOString().split('T')[0];
    const eventOnDate = events.find(event => {
      const eventDate = new Date(event.start).toISOString().split('T')[0];
      return eventDate === clickedDate;
    });

    if (eventOnDate) {
      setSelectedEvent(eventOnDate); // Set selected event details
      setShowModal(true); // Open modal
    } else {
      setSelectedEvent(null); // No event on this date
      setShowModal(true); // Open modal even if no event (optional)
    }
  };

  // Close modal handler
  const handleCloseModal = () => {
    setShowModal(false);
  };

  return (
    <div className="calendar-container">
      {loading ? (
        <p>Loading events...</p>
      ) : error ? (
        <p>{error}</p>
      ) : (
        <FullCalendar
          plugins={[dayGridPlugin, interactionPlugin]}
          initialView="dayGridMonth"
          headerToolbar={{
            left: 'prev,next today',
            center: 'title',
            right: 'dayGridMonth,dayGridWeek,dayGridDay'
          }}
          events={events}
          dateClick={handleDateClick} // Handle date clicks to show modal
          dayCellContent={(info) => (
            <Tooltip 
              title={hoveredDate === info.dateStr ? "No events booked on this date" : ''} 
              arrow
              placement="top"
            >
              <div 
                onMouseEnter={() => handleMouseEnter(info)} 
                onMouseLeave={handleMouseLeave}
                style={{ cursor: 'pointer' }} 
              >
                {info.dayNumberText} {/* Display day number */}
              </div>
            </Tooltip>
          )}
        />
      )}

      {/* Modal to show event details */}
      <Modal show={showModal} onHide={handleCloseModal} centered>
        <Modal.Header closeButton>
          <Modal.Title>
            {selectedEvent ? `Event on ${new Date(selectedEvent.start).toLocaleDateString()}` : 'No Events'}
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {selectedEvent ? (
            <div>
              <p><strong>Event:</strong> {selectedEvent.title}</p>
              <p><strong>Hall:</strong> {selectedEvent.hall}</p>
            </div>
          ) : (
            <p>No events booked on this date.</p>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseModal}>
            Close
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default Calendar;
