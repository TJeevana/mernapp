import React, { useState, useMemo } from 'react';
import countryList from 'react-select-country-list';
import '../css/ContactDetails.css';

const ContactDetails = () => {
  const [value, setValue] = useState('');
  const [email, setEmail] = useState('');
  const [mobile, setMobile] = useState('');
  const [emailError, setEmailError] = useState('');
  const [mobileError, setMobileError] = useState('');
  
  const options = useMemo(() => countryList().getData(), []);

  const changeHandler = (event) => {
    setValue(event.target.value);
  };

  // Email validation
  const validateEmail = (event) => {
    const emailValue = event.target.value;
    setEmail(emailValue);
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!regex.test(emailValue)) {
      setEmailError('Please enter a valid email address.');
    } else {
      setEmailError('');
    }
  };

  // Mobile number validation
  const validateMobile = (event) => {
    const mobileValue = event.target.value;
    setMobile(mobileValue);
    const mobileRegex = /^[0-9]{10}$/; // 10-digit mobile number
    if (!mobileRegex.test(mobileValue)) {
      setMobileError('Please enter a valid 10-digit mobile number.');
    } else {
      setMobileError('');
    }
  };

  return (
    <div class="contactdetails">
      <div class="name">
        <label>
          Name<span className="required">*</span>
        </label>
        <div className="name-inputs">
          <input type="text" placeholder="First Name" class="name1-input" />
          <input type="text" placeholder="Last Name" class="name2-input" />
        </div>
      </div><br/>

      <div className="address">
        <label>
          Address<span className="required">*</span>
        </label>
        <div className="address-inputs">
          <input type="text" placeholder="Street Name" className="street-input" />
          <input type="text" placeholder="City Name" className="city-input" />
          <input type="text" placeholder="State/Province" className="state-input" />
          <input type="text" placeholder="Postal Code" className="postal-input" />
          <select value={value} onChange={changeHandler} className="Country-input">
            <option value="">Select your country</option>
            {options.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      </div><br/>

      <div class="email">
        <label>
          Email<span className="required">*</span>
        </label>
        <input
          type="email"
          placeholder="Enter your email"
          class="email-input"
          value={email}
          onChange={validateEmail}
        />
        {emailError && <span className="error">{emailError}</span>}
      </div><br/>

      <div className="mobileno">
        <label>
          Mobile No<span className="required">*</span>
        </label>
        <input
          type="text"
          placeholder="Enter your mobile number"
          class="mobile-input"
          value={mobile}
          onChange={validateMobile}
        />
        {mobileError && <span className="error">{mobileError}</span>}
      </div>
    </div>
  );
};

export default ContactDetails;
