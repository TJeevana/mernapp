//HallCard.js
import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom'; // For client-side navigation
import axios from 'axios';
import '../css/HallCard.css'; // Ensure your custom CSS file is correctly imported

// HallCard Component
const HallCard = ({ hallName, capacity, rating, hallId }) => {
  const navigate = useNavigate(); // Use React Router's navigation hook

  return (
    <div className="col-md-4 mb-4">
      <div className="card hall-card" style={{ backgroundColor: '#333', color: 'white', width: '18rem' }}>
        <div className="card-body text-center">
          <h5 className="card-title" style={{ fontFamily: 'Allura, cursive', color: '#c9630a' }}>
            {hallName}
          </h5>
          <div className="card-text" style={{ color: '#f5ede4', }}> {/* Set color to white here */}
            Capacity: {capacity}
          </div>
          <div className="card-rating">
            Rating: {'★'.repeat(Math.floor(rating))}{'☆'.repeat(5 - Math.floor(rating))}
          </div>
          <button
            className="btn btn-warning booking-btn"
            style={{ backgroundColor: '#e69812', border: 'none', color: 'black' }}
            onClick={() => navigate(`/bookingInfo/${hallId}`)} // Use navigate to change route
          >
            Book Now
          </button>
        </div>
      </div>
    </div>
  );
};

// HallList Component to fetch and display list of halls
const HallList = () => {
  const [halls, setHalls] = useState([]); // State for storing fetched hall data

  useEffect(() => {
    const fetchHalls = async () => {
      try {
        const { data } = await axios.get('api/v1/hall'); // API request to get hall data
        console.log('Fetched halls:', data.halls); // Debug: log data to see the structure
        setHalls(data.halls); // Update state with the fetched halls
      } catch (error) {
        console.error('Error fetching hall data:', error); // Log any errors that occur
      }
    };

    fetchHalls(); // Call fetch function on component mount
  }, []); // Empty dependency array ensures this only runs once when the component is mounted

  return (
    <div className="container">
      <div className="row">
        {halls.length > 0 ? ( // Conditional rendering: if halls are available, map them
          halls.map((hall) => (
            <HallCard
              key={hall._id} // Unique key for each hall
              hallName={hall.name}
              capacity={hall.capacity}
              rating={hall.ratings}
              hallId={hall._id}
            />
          ))
        ) : (
          <p>No halls available.</p> // Message if no halls are fetched
        )}
      </div>
    </div>
  );
};

export default HallList;

/*
import React from 'react';

const HallCard = ({ imgSrc, hallName, capacity, price }) => (
  <div className="card">
    <img src={imgSrc} className="card-img-top" alt={hallName} />
    <div className="card-body text-center">
      <h5 className="card-title" style={{ fontFamily: 'Allura, cursive', color: '#c9630a' }}>{hallName}</h5>
      <p className="card-text">
        Person Capacity: {capacity} <br />
        Price: {price} $
      </p>
      <button className="btn btn-primary booking-btn" onClick={() => window.open(`/bookingInfo/${hallName}`, '_blank')}>
        Book Now
      </button>
    </div>
  </div>
);

export default HallCard;
*/