// Booking.js
import React from 'react';
import image from '../images/image.jpg'; 
import '../css/Booking.css'; 
import HallList from './HallCard'; //

const Booking = () => {
  
  return (
    <div>
      <div className="card bg-dark text-white">
        <img
          src={image}
          className="card-img card-img-custom"
          alt="Reservation"
        />
        <div className="card-img-overlay text-left-margin">
          <h1 className="card-title custom-title">Quick & Easy Hall Booking</h1>
          <h3 className="card-text custom-text">Make Your Fastest Reservation</h3><br />
          <p className="card-text custom-text">Hurry up!</p>
        </div>
      </div>

      <div className="available-halls-container">
        <h3 style={{ textAlign: 'center', marginTop: '80px', fontFamily: 'Allura, cursive', color: '#c9630a' }}>Available Halls</h3>
        <p style={{ textAlign: 'center', marginTop: '10px', marginLeft: '150px', marginRight: '150px', fontFamily: 'Allura, cursive', color: 'black' }}>
          Pxier Table reservation portal allows you to visualize the reservations and manage day-to-day reservation
          activities. Color code reservation status allows you to quickly see the status of each reservation. You can also
          manage the waiting list and cancellations. With the Pxier
          table reservation app, it's easy to move reservations from one table to another.
        </p>
      </div>
      
      <div className='mappcard'>
        {/* Additional content can go here if needed */}
        <HallList />
      </div>

      <div className='calender'>
       
      </div>
      
    </div>
  );
};

export default Booking;
