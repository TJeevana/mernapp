import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
//import '../css/Forgotpassword.css';

function Forgotpassword() {
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const navigate = useNavigate();

  const handleResetpassword = async (e) => {
    e.preventDefault();
    try {
      const { data } = await axios.post("http://localhost:8000/api/v1/forgot-password", {
        email,
      });

      if (data.success) {
        setMessage("Check your email for the reset link.");
      }
    } catch (err) {
      setMessage("Failed to send reset email. Please try again.");
    }
  };

  return (
    <div className="container forgot-password">
      <form onSubmit={handleResetpassword}> {/* Ensure this matches the defined function name */}
        <h3>Forgot Password</h3>
        <div className="form-group">
          <input
            type="email"
            className="form-control"
            placeholder="Enter your email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>
        <button type="submit" className="btn btn-primary">Send Reset Link</button>
        {message && <p className="text-info">{message}</p>}
        <p>
          Remembered your password? <button className="btn btn-link" onClick={() => navigate('/login')}>Login</button>
        </p>
      </form>
    </div>
  );
  
}

export default Forgotpassword;
