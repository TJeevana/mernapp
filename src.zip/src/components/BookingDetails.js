import React from 'react';
import { useParams } from 'react-router-dom'; 
import '../css/BookingDetails.css';

const BookingDetails = () => {

  const { hall } = useParams();

  return (
    <form>
      {/* Row 1 */}
      <div className="form-row1">
        <div className="d1">
          <label>
            Booking Type <span className="required">*</span>
          </label>
          <div className="radio-group1">
            <input type="radio" id="private" name="bookingType" value="Private" required />
            <label>Private</label> &nbsp;
            <input type="radio" id="organization" name="bookingType" value="Organization/Public" required />
            <label>Organization/Public</label>
          </div>
        </div>

        <div className="d2">
          <label>
            Event Type <span className="required">*</span>
          </label>
          <div className="selectgrp1">
            <select id="eventType" required>
              <option value="" disabled selected>
                Please select
              </option>
              {/* Event type options */}
              <option value="Arangetram">Arangetram</option>
              <option value="Birthday Party">Birthday Party</option>
              {/* Add other options */}
            </select>
          </div>
        </div>
      </div>

      {/* Row 2 */}
      <div className="form-row2">
        <div className="hall">
          <label>
            Hall Name <span className="required">*</span>
          </label>
          <input type="text" id="hallName" value={hall} readOnly />
        </div>
        <div className="noofgst">
          <label>
            No. of Guests <span className="required">*</span>
          </label>
          <input type="number" id="guestCount" placeholder="Enter number of guests" required />
        </div>
      </div>

      {/* Row 3 */}
      <div className="form-row3">
        <div className="date">
          <label>
            Booking Date <span className="required">*</span>
          </label>
          <input type="date" id="bookingDate" required />
        </div>
        <div className="fromtime">
          <label>
            Time From <span className="required">*</span>
          </label>
          <div className="fromtime-input">
            <input type="time" id="timeFrom" required step="60" placeholder="__:__" />
            <select id="amPmFrom" required>
                <option value="AM" class ="am">AM</option>
                <option value="PM" class ="pm">PM</option>
            </select>
          </div>
        </div>

        <div className="totime">
          <label>
            Time To <span className="required">*</span>
          </label>
          <div className="timeto-input">
            <input type="time" id="timeTo" required step="60" placeholder="__:__" />
            <select id="amPmTo" required>
              <option value="AM" class ="am">AM</option>
              <option value="PM" class ="pm">PM</option>
            </select>
          </div>
        </div>
      </div>

      {/* Row 4 */}
      <div className="form-row4">
        <label>Add-on services that you are interested in:</label>
        <div className="checkbox-group1">
          <div>
            <input type="checkbox" id="tableChairDecoration" />
            <label>Table & Chair Decoration</label>
          </div>
          <div>
            <input type="checkbox" id="catering" />
            <label>Catering</label>
          </div>

          <div>
            <input type="checkbox" id="cutleries" />
            <label>Cutleries, Crockery and Glassware</label>
          </div>

          <div>
            <input type="checkbox" id="eventLiveTelecast" />
            <label>Event Live Telecast</label>
          </div>

          <div>
            <input type="checkbox" id="videography" />
            <label>Videography</label>
           </div>

           <div>
            <input type="checkbox" id="soundSystemManagement" />
            <label>Sound System Management</label>
           </div>

            <div>
             <input type="checkbox" id="otherServices" />
             <label>Other</label>
            </div>
        </div>
        <div className="checkbox-group2">
          <div>
            <input type="checkbox" id="hallStageDecoration" />
            <label>Hall & Stage Decoration</label>
          </div>

          <div>
            <input type="checkbox" id="softdrinks" />
            <label>Softdrinks</label>
          </div>

          <div>
            <input type="checkbox" id="waiters" />
            <label>Waiters</label>
          </div>
                   
           <div>
             <input type="checkbox" id="djSystem" />
             <label>DJ System</label>
           </div>
           
           <div>
              <input type="checkbox" id="photography" />
              <label>Photography</label>
           </div>   
        </div>
      </div>

      {/* Row 5 */}
      <div className="form-row5">
        <div className="form-group full-width">
          <label>Any Other Information</label>
          <textarea id="additionalInfo" rows="5" placeholder="Enter any additional information here..." className="additional-info-textarea"></textarea>
        </div>
      </div>
    </form>
  );
};

export default BookingDetails;
