import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import '../css/Login.css';

function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    try {
        const { data } = await axios.post("http://localhost:8000/api/v1/login", {
            email,
            password,
        });

        if (data.success && data.token) {
            
            localStorage.setItem("authToken", data.token);

            
            const userId = data.userId;

            switch (data.role) {
                case 'admin':
                    navigate("/admin/dashboard", { state: { email, role: data.role, userId } });
                    break;
                case 'agent':
                    navigate("/agent/dashboard/content", { state: { email, role: data.role, userId } });
                    break;
                case 'member':
                    navigate("/member/dashboard", { state: { email, role: data.role, userId } });
                    break;
                default:
                    navigate("/dashboard");
                    break;
            }
        } else {
            setError("Login failed, please check your credentials.");
        }
    } catch (err) {
        if (err.response) {
            setError("Invalid email or password.");
        } else if (err.request) {
            setError("Network error, please try again.");
        } else {
            setError("An unexpected error occurred.");
        }
    }
};


  return (
    <div className="login-container d-flex align-items-center justify-content-center">
      
      <form className="login-form p-4" onSubmit={handleLogin}>
        <div data-mdb-input-init className="form-outline mb-4">
          <h1 style={{color:' rgb(214, 208, 20)'}}>Login</h1>
          <input
            type="email"
            id="form2Example1"
            className="form-control"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required style={{height:'40px' , borderRadius:'10px'}}
          />
          <label className="form-label" htmlFor="form2Example1" style={{fontSize:'17px'}}>Email address</label>
        </div>

        <div data-mdb-input-init className="form-outline mb-4">
          <input
            type="password"
            id="form2Example2"
            className="form-control"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required style={{height:'40px' , borderRadius:'10px'}}
          />
          <label className="form-label" htmlFor="form2Example2"  style={{fontSize:'17px'}}>Password</label>
        </div>

        <div className="row mb-4">
          <div className="col">
            <a href="#!" onClick={() => navigate('/forgotpassword')}>Forgot password?</a>
          </div>
        </div>

        {error && <p className="text-danger">{error}</p>}

        <button type="submit" className="btn btn-primary btn-block mb-4" style={{marginLeft:'0px'}}>
          Login
        </button>

        <div className="text">
          <p>Not a member? <a href="#!" onClick={() => navigate('/register')}>Register</a></p>
        </div>
      </form>
    </div>
  );
}

export default Login;
