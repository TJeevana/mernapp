import React, { useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import '../css/Register.css';

const FormInput = ({ type, placeholder, value, onChange, required }) => (
  <div className="form-group">
    <input
      type={type}
      className="form-control"
      placeholder={placeholder}
      value={value}
      onChange={onChange}
      required={required}
    />
  </div>
);

function Register() {
  const [userType, setUserType] = useState("member");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const navigate = useNavigate();

  const isValidEmail = (email) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);

  const handleRegister = async (e) => {
    e.preventDefault();

    if (!isValidEmail(email)) {
      return setError("Invalid email format");
    }
    if (password !== confirmPassword) {
      return setError("Passwords do not match");
    }
    if (password.length < 6) {
      return setError("Password must be at least 6 characters long");
    }

    const agentRequested = userType === "agent";

    try {
      const payload = {
        username,
        email,
        password,
        role: userType,  // Use the userType value here
        agentRequested,
      };

      const { data } = await axios.post("http://localhost:8000/api/v1/register", payload);

      if (data.success) {
        if (userType === "agent") {
          setSuccessMessage("Agent registration requires admin approval.");
          navigate("/login");
        } else {
          setSuccessMessage("Registration successful! You can now log in.");
          navigate("/login");
        }
      } else {
        setError(data.message || "Registration failed. Please try again.");
      }
    } catch (err) {
      setError("Registration failed. Please try again.");
      console.error(err);
    }
  };

  return (
    <div className="container register mt-4">
      <div className="row">
        <div className="col-md-3 register-left">
          <img src="https://image.ibb.co/n7oTvU/logo_white.png" alt="Logo" />
          <h3>Welcome</h3>
          <p>Already have an account?</p>
          <button onClick={() => navigate('/login')} className="btn btn-primary" style={{marginLeft:'0'}}>Login</button>
        </div>
        <div className="col-md-9 register-right">
          <div className="tab-content" id="myTabContent">
            <ul className="nav nav-tabs justify-content-center" id="myTab" role="tablist">
              <li className="nav-item">
                <a 
                  className={`nav-link ${userType === "member" ? "active" : ""}`} 
                  id="member-tab" 
                  data-bs-toggle="tab" 
                  href="#member" 
                  role="tab" 
                  onClick={() => setUserType("member")}>
                  Member
                </a>
              </li>
              <li className="nav-item">
                <a 
                  className={`nav-link ${userType === "agent" ? "active" : ""}`} 
                  id="agent-tab" 
                  data-bs-toggle="tab" 
                  href="#agent" 
                  role="tab" 
                  onClick={() => setUserType("agent")}>
                  Agent
                </a>
              </li>
            </ul>

            {/* Member registration form */}
            <div className={`tab-pane fade ${userType === "member" ? "show active" : ""}`} id="home" role="tabpanel">
              <h3 className="register-heading">Apply as a Member</h3>
              <form className="row register-form" onSubmit={handleRegister}>
                <FormInput type="text" placeholder="User Name *" value={username} onChange={(e) => setUsername(e.target.value)} required />
                <FormInput type="email" placeholder="Your Email *" value={email} onChange={(e) => setEmail(e.target.value)} required />
                <FormInput type="password" placeholder="Password *" value={password} onChange={(e) => setPassword(e.target.value)} required />
                <FormInput type="password" placeholder="Confirm Password *" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required />
                <div className="col-md-12">
                  <input type="submit" className="btnRegister" value="Register" />
                </div>
              </form>
            </div>

            {/* Agent registration form */}
            <div className={`tab-pane fade ${userType === "agent" ? "show active" : ""}`} id="profile" role="tabpanel">
              <h3 className="register-heading">Apply as an Agent</h3>
              <form className="row register-form" onSubmit={handleRegister}>
                <FormInput type="text" placeholder="User Name *" value={username} onChange={(e) => setUsername(e.target.value)} required />
                <FormInput type="email" placeholder="Your Email *" value={email} onChange={(e) => setEmail(e.target.value)} required />
                <FormInput type="password" placeholder="Password *" value={password} onChange={(e) => setPassword(e.target.value)} required />
                <FormInput type="password" placeholder="Confirm Password *" value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} required />
                <div className="col-md-12">
                  <input type="submit" className="btnRegister" value="Register" />
                </div>
              </form>
            </div>
          </div>
          
          {/* Error and Success Message */}
          {error && <p className="text-danger">{error}</p>}
          {successMessage && <p className="text-success">{successMessage}</p>}
        </div>
      </div>
    </div>
  );
}

export default Register;