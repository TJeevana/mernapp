// BookingForm.js
import React from 'react';
import { useParams } from 'react-router-dom'; 
import { useLocation } from 'react-router-dom';
import ContactDetails from './ContactDetails';
import BookingDetails from './BookingDetails';


const BookingForm = () => {

    const { hall } = useParams();
    const location = useLocation();
  const selectedDate = location.state?.selectedDate || 'No date selected';
  return (
    <div class="bookingform" style={{margin: '50px',backgroundColor: '#f3f4f5',padding: '20px',borderRadius: '8px'}}>
        <div class="headding" style={{textAlign: 'center'}}>
            <h2>Booking Form :{hall}</h2>
        </div>
        <hr/>
        <div class="bookingdetails" style={{marginLeft:'30px',marginRight:'30px',marginTop: '50px',marginBottom:'30px',textAlign: 'left',backgroundColor: '#82827f78', border:'1px solidblack'}}>
            <h4> Booking Details</h4>
        </div> 
            <div style={{marginLeft:'30px',marginRight:'30px'}}>
               <BookingDetails/>
            </div>

        <div class="bookingdetails" style={{marginLeft:'30px',marginRight:'30px',marginTop: '50px',marginBottom:'30px',textAlign: 'left',backgroundColor: '#82827f78', border:'1px solidblack'}}> 
            <h4> Contact Details</h4>
        </div>
            <div style={{marginLeft:'30px',marginRight:'30px'}}>
               <ContactDetails/>
            </div>
        
        <button style={{border:'1px solidblack', marginLeft:'30px',marginTop:'20px', padding:'10px'}}>Cancel</button>
        <button style={{border:'1px solidblack', marginLeft:'1020px',marginTop:'20px',padding:'1px',backgroundColor:'blue'}}>Submit</button>

    </div>

  );
};

export default BookingForm;
