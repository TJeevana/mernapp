// AboutUs.js
import React from 'react';

const AboutUs = () => {
  return (
    <div>
      <h1>About Us</h1>
      <p>Here you can add information about your organization.</p>
      {/* Add more content as needed */}
    </div>
  );
};

export default AboutUs;
