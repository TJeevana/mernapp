import React from 'react'

const AgentLayout = () => {
  return (
    <div>
      hi
    </div>
  )
}

export default AgentLayout
