import React from 'react'

const UserLayout = () => {
  return (
    <div>
      
    </div>
  )
}

export default UserLayout
