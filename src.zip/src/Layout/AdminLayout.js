import React from 'react'

const AdminLayout = () => {
  return (
    <div>
      
    </div>
  )
}

export default AdminLayout
